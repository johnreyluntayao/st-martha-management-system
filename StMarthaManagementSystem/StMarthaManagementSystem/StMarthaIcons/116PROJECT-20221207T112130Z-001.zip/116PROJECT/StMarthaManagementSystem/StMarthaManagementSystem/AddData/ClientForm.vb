﻿Public Class ClientForm

    Dim gender As String
    Dim genderBind As String

    Private Sub save_bttn_Click(sender As Object, e As EventArgs) Handles save_bttn.Click
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
        conn.Open()
        cmd = conn.CreateCommand()
        cmd.CommandText = "INSERT INTO contract_client (`Client_Name`,`Age`,`Address`,`Contact_Number`,`Gender`) VALUES('" & clientName.Text & "','" & age.Text & "','" & address.Text & "','" & contactNum.Text & "','" & gender & "')"
        If cmd.ExecuteNonQuery() Then
            MessageBox.Show("DATA ADDED SUCCESSFULLY IN THE DATABASE!", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
        Else
            MessageBox.Show("FAILED TO ADD DATA!", "Error", MessageBoxButtons.OK, MessageBoxIcon.Information)
        End If
    End Sub
    Private Sub radmale_CheckedChanged(sender As Object, e As EventArgs) Handles radmale.CheckedChanged
        gender = "Male"
    End Sub
    Private Sub radfemale_CheckedChanged(sender As Object, e As EventArgs) Handles radfemale.CheckedChanged
        gender = "Female"
    End Sub

    Private Sub clientName_TextChanged(sender As Object, e As EventArgs) Handles clientName.TextChanged

    End Sub
End Class