﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class ContractInformation
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.deceasedID_TB = New Guna.UI2.WinForms.Guna2TextBox()
        Me.clientID_TB = New Guna.UI2.WinForms.Guna2TextBox()
        Me.selectPackages = New Guna.UI2.WinForms.Guna2Button()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.uploadAuthorizedSig_bttn = New Guna.UI2.WinForms.Guna2Button()
        Me.save_bttn = New Guna.UI2.WinForms.Guna2Button()
        Me.clientName_CB = New System.Windows.Forms.ComboBox()
        Me.adminSigPic = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.clientSigPic = New Guna.UI2.WinForms.Guna2PictureBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.totalamount = New Guna.UI2.WinForms.Guna2TextBox()
        Me.uploadClientSig_bttn = New Guna.UI2.WinForms.Guna2Button()
        Me.datecontract = New Guna.UI2.WinForms.Guna2DateTimePicker()
        Me.deceasedbirthdate = New Guna.UI2.WinForms.Guna2DateTimePicker()
        Me.deceaseddatedeath = New Guna.UI2.WinForms.Guna2DateTimePicker()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.deceasedaddress = New Guna.UI2.WinForms.Guna2TextBox()
        Me.deceasedage = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.namedeceased = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel2 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.relationship = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Guna2HtmlLabel1 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.contactnumber = New Guna.UI2.WinForms.Guna2TextBox()
        Me.address = New Guna.UI2.WinForms.Guna2TextBox()
        Me.age = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Panel2.SuspendLayout()
        CType(Me.adminSigPic, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.clientSigPic, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.Panel2.Controls.Add(Me.deceasedID_TB)
        Me.Panel2.Controls.Add(Me.clientID_TB)
        Me.Panel2.Controls.Add(Me.selectPackages)
        Me.Panel2.Controls.Add(Me.Label17)
        Me.Panel2.Controls.Add(Me.uploadAuthorizedSig_bttn)
        Me.Panel2.Controls.Add(Me.save_bttn)
        Me.Panel2.Controls.Add(Me.clientName_CB)
        Me.Panel2.Controls.Add(Me.adminSigPic)
        Me.Panel2.Controls.Add(Me.Label10)
        Me.Panel2.Controls.Add(Me.clientSigPic)
        Me.Panel2.Controls.Add(Me.Label9)
        Me.Panel2.Controls.Add(Me.totalamount)
        Me.Panel2.Controls.Add(Me.uploadClientSig_bttn)
        Me.Panel2.Controls.Add(Me.datecontract)
        Me.Panel2.Controls.Add(Me.deceasedbirthdate)
        Me.Panel2.Controls.Add(Me.deceaseddatedeath)
        Me.Panel2.Controls.Add(Me.Label24)
        Me.Panel2.Controls.Add(Me.deceasedaddress)
        Me.Panel2.Controls.Add(Me.deceasedage)
        Me.Panel2.Controls.Add(Me.Label23)
        Me.Panel2.Controls.Add(Me.namedeceased)
        Me.Panel2.Controls.Add(Me.Guna2HtmlLabel2)
        Me.Panel2.Controls.Add(Me.relationship)
        Me.Panel2.Controls.Add(Me.Guna2HtmlLabel1)
        Me.Panel2.Controls.Add(Me.Label3)
        Me.Panel2.Controls.Add(Me.contactnumber)
        Me.Panel2.Controls.Add(Me.address)
        Me.Panel2.Controls.Add(Me.age)
        Me.Panel2.Controls.Add(Me.Label5)
        Me.Panel2.Controls.Add(Me.Label6)
        Me.Panel2.Controls.Add(Me.Label7)
        Me.Panel2.Controls.Add(Me.Label14)
        Me.Panel2.Controls.Add(Me.Label12)
        Me.Panel2.Controls.Add(Me.Label11)
        Me.Panel2.Controls.Add(Me.Label8)
        Me.Panel2.Controls.Add(Me.Label4)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Panel2.Location = New System.Drawing.Point(0, 71)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(968, 601)
        Me.Panel2.TabIndex = 1
        '
        'deceasedID_TB
        '
        Me.deceasedID_TB.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.deceasedID_TB.DefaultText = ""
        Me.deceasedID_TB.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.deceasedID_TB.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.deceasedID_TB.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.deceasedID_TB.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.deceasedID_TB.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.deceasedID_TB.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.deceasedID_TB.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.deceasedID_TB.Location = New System.Drawing.Point(358, 282)
        Me.deceasedID_TB.Name = "deceasedID_TB"
        Me.deceasedID_TB.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.deceasedID_TB.PlaceholderText = ""
        Me.deceasedID_TB.SelectedText = ""
        Me.deceasedID_TB.Size = New System.Drawing.Size(53, 36)
        Me.deceasedID_TB.TabIndex = 269
        Me.deceasedID_TB.Visible = False
        '
        'clientID_TB
        '
        Me.clientID_TB.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.clientID_TB.DefaultText = ""
        Me.clientID_TB.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.clientID_TB.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.clientID_TB.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.clientID_TB.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.clientID_TB.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.clientID_TB.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.clientID_TB.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.clientID_TB.Location = New System.Drawing.Point(366, 22)
        Me.clientID_TB.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.clientID_TB.Name = "clientID_TB"
        Me.clientID_TB.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.clientID_TB.PlaceholderText = ""
        Me.clientID_TB.SelectedText = ""
        Me.clientID_TB.Size = New System.Drawing.Size(63, 37)
        Me.clientID_TB.TabIndex = 268
        Me.clientID_TB.Visible = False
        '
        'selectPackages
        '
        Me.selectPackages.BorderColor = System.Drawing.SystemColors.ButtonHighlight
        Me.selectPackages.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.selectPackages.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.selectPackages.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.selectPackages.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.selectPackages.FillColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.selectPackages.Font = New System.Drawing.Font("Century Gothic", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.selectPackages.ForeColor = System.Drawing.Color.White
        Me.selectPackages.Location = New System.Drawing.Point(11, 513)
        Me.selectPackages.Name = "selectPackages"
        Me.selectPackages.Size = New System.Drawing.Size(308, 45)
        Me.selectPackages.TabIndex = 267
        Me.selectPackages.Text = "Select Packages"
        '
        'Label17
        '
        Me.Label17.Font = New System.Drawing.Font("Candara", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label17.Location = New System.Drawing.Point(679, 495)
        Me.Label17.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(163, 21)
        Me.Label17.TabIndex = 218
        Me.Label17.Text = "Authorized Signature"
        '
        'uploadAuthorizedSig_bttn
        '
        Me.uploadAuthorizedSig_bttn.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.uploadAuthorizedSig_bttn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.uploadAuthorizedSig_bttn.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.uploadAuthorizedSig_bttn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.uploadAuthorizedSig_bttn.FillColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.uploadAuthorizedSig_bttn.Font = New System.Drawing.Font("Candara", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.uploadAuthorizedSig_bttn.ForeColor = System.Drawing.Color.White
        Me.uploadAuthorizedSig_bttn.Location = New System.Drawing.Point(865, 488)
        Me.uploadAuthorizedSig_bttn.Name = "uploadAuthorizedSig_bttn"
        Me.uploadAuthorizedSig_bttn.Size = New System.Drawing.Size(66, 28)
        Me.uploadAuthorizedSig_bttn.TabIndex = 221
        Me.uploadAuthorizedSig_bttn.Text = "Upload"
        '
        'save_bttn
        '
        Me.save_bttn.BorderColor = System.Drawing.SystemColors.ButtonHighlight
        Me.save_bttn.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.save_bttn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.save_bttn.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.save_bttn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.save_bttn.FillColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.save_bttn.Font = New System.Drawing.Font("Century Gothic", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.save_bttn.ForeColor = System.Drawing.Color.White
        Me.save_bttn.Location = New System.Drawing.Point(751, 534)
        Me.save_bttn.Name = "save_bttn"
        Me.save_bttn.Size = New System.Drawing.Size(180, 45)
        Me.save_bttn.TabIndex = 223
        Me.save_bttn.Text = "Save"
        '
        'clientName_CB
        '
        Me.clientName_CB.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.clientName_CB.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.clientName_CB.Font = New System.Drawing.Font("Candara", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.clientName_CB.FormattingEnabled = True
        Me.clientName_CB.Location = New System.Drawing.Point(22, 67)
        Me.clientName_CB.Name = "clientName_CB"
        Me.clientName_CB.Size = New System.Drawing.Size(336, 35)
        Me.clientName_CB.TabIndex = 266
        '
        'adminSigPic
        '
        Me.adminSigPic.ImageRotate = 0!
        Me.adminSigPic.Location = New System.Drawing.Point(621, 397)
        Me.adminSigPic.Name = "adminSigPic"
        Me.adminSigPic.Size = New System.Drawing.Size(310, 90)
        Me.adminSigPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.adminSigPic.TabIndex = 222
        Me.adminSigPic.TabStop = False
        '
        'Label10
        '
        Me.Label10.Font = New System.Drawing.Font("Candara", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(680, 270)
        Me.Label10.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(142, 22)
        Me.Label10.TabIndex = 265
        Me.Label10.Text = "Client's Signature"
        '
        'clientSigPic
        '
        Me.clientSigPic.ImageRotate = 0!
        Me.clientSigPic.Location = New System.Drawing.Point(622, 174)
        Me.clientSigPic.Name = "clientSigPic"
        Me.clientSigPic.Size = New System.Drawing.Size(310, 90)
        Me.clientSigPic.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.clientSigPic.TabIndex = 264
        Me.clientSigPic.TabStop = False
        '
        'Label9
        '
        Me.Label9.Font = New System.Drawing.Font("Candara", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(396, 561)
        Me.Label9.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(118, 21)
        Me.Label9.TabIndex = 219
        Me.Label9.Text = "Total Amount:"
        '
        'totalamount
        '
        Me.totalamount.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.totalamount.DefaultText = ""
        Me.totalamount.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.totalamount.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.totalamount.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.totalamount.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.totalamount.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.totalamount.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.totalamount.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.totalamount.Location = New System.Drawing.Point(365, 513)
        Me.totalamount.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.totalamount.Name = "totalamount"
        Me.totalamount.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.totalamount.PlaceholderText = ""
        Me.totalamount.SelectedText = ""
        Me.totalamount.Size = New System.Drawing.Size(193, 45)
        Me.totalamount.TabIndex = 220
        '
        'uploadClientSig_bttn
        '
        Me.uploadClientSig_bttn.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.uploadClientSig_bttn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.uploadClientSig_bttn.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.uploadClientSig_bttn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.uploadClientSig_bttn.FillColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.uploadClientSig_bttn.Font = New System.Drawing.Font("Candara", 7.8!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.uploadClientSig_bttn.ForeColor = System.Drawing.Color.White
        Me.uploadClientSig_bttn.Location = New System.Drawing.Point(866, 264)
        Me.uploadClientSig_bttn.Name = "uploadClientSig_bttn"
        Me.uploadClientSig_bttn.Size = New System.Drawing.Size(66, 28)
        Me.uploadClientSig_bttn.TabIndex = 263
        Me.uploadClientSig_bttn.Text = "Upload"
        '
        'datecontract
        '
        Me.datecontract.BackColor = System.Drawing.Color.Transparent
        Me.datecontract.Checked = True
        Me.datecontract.CustomFormat = "yyyy/MM/dd"
        Me.datecontract.FillColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.datecontract.Font = New System.Drawing.Font("Candara", 10.2!, System.Drawing.FontStyle.Bold)
        Me.datecontract.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.datecontract.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.datecontract.Location = New System.Drawing.Point(785, 67)
        Me.datecontract.MaxDate = New Date(9998, 12, 31, 0, 0, 0, 0)
        Me.datecontract.MinDate = New Date(1753, 1, 1, 0, 0, 0, 0)
        Me.datecontract.Name = "datecontract"
        Me.datecontract.Size = New System.Drawing.Size(147, 41)
        Me.datecontract.TabIndex = 248
        Me.datecontract.Value = New Date(2022, 11, 22, 16, 42, 24, 410)
        '
        'deceasedbirthdate
        '
        Me.deceasedbirthdate.Checked = True
        Me.deceasedbirthdate.CustomFormat = "yyyy/MM/dd"
        Me.deceasedbirthdate.FillColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.deceasedbirthdate.Font = New System.Drawing.Font("Candara", 10.2!, System.Drawing.FontStyle.Bold)
        Me.deceasedbirthdate.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.deceasedbirthdate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.deceasedbirthdate.Location = New System.Drawing.Point(503, 331)
        Me.deceasedbirthdate.MaxDate = New Date(9998, 12, 31, 0, 0, 0, 0)
        Me.deceasedbirthdate.MinDate = New Date(1753, 1, 1, 0, 0, 0, 0)
        Me.deceasedbirthdate.Name = "deceasedbirthdate"
        Me.deceasedbirthdate.Size = New System.Drawing.Size(168, 38)
        Me.deceasedbirthdate.TabIndex = 247
        Me.deceasedbirthdate.Value = New Date(2022, 11, 22, 16, 42, 24, 410)
        '
        'deceaseddatedeath
        '
        Me.deceaseddatedeath.Checked = True
        Me.deceaseddatedeath.CustomFormat = "yyyy/MM/dd"
        Me.deceaseddatedeath.FillColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.deceaseddatedeath.Font = New System.Drawing.Font("Candara", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.deceaseddatedeath.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.deceaseddatedeath.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.deceaseddatedeath.Location = New System.Drawing.Point(755, 331)
        Me.deceaseddatedeath.MaxDate = New Date(9998, 12, 31, 0, 0, 0, 0)
        Me.deceaseddatedeath.MinDate = New Date(1753, 1, 1, 0, 0, 0, 0)
        Me.deceaseddatedeath.Name = "deceaseddatedeath"
        Me.deceaseddatedeath.Size = New System.Drawing.Size(176, 38)
        Me.deceaseddatedeath.TabIndex = 244
        Me.deceaseddatedeath.Value = New Date(2022, 11, 22, 16, 42, 24, 410)
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.Font = New System.Drawing.Font("Candara", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.Location = New System.Drawing.Point(31, 439)
        Me.Label24.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(117, 17)
        Me.Label24.TabIndex = 243
        Me.Label24.Text = "Complete Address"
        '
        'deceasedaddress
        '
        Me.deceasedaddress.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.deceasedaddress.DefaultText = ""
        Me.deceasedaddress.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.deceasedaddress.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.deceasedaddress.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.deceasedaddress.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.deceasedaddress.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.deceasedaddress.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me.deceasedaddress.ForeColor = System.Drawing.Color.Black
        Me.deceasedaddress.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.deceasedaddress.Location = New System.Drawing.Point(22, 397)
        Me.deceasedaddress.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.deceasedaddress.Name = "deceasedaddress"
        Me.deceasedaddress.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.deceasedaddress.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.deceasedaddress.PlaceholderText = "Complete Address"
        Me.deceasedaddress.SelectedText = ""
        Me.deceasedaddress.Size = New System.Drawing.Size(503, 38)
        Me.deceasedaddress.TabIndex = 242
        '
        'deceasedage
        '
        Me.deceasedage.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.deceasedage.DefaultText = ""
        Me.deceasedage.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.deceasedage.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.deceasedage.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.deceasedage.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.deceasedage.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.deceasedage.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me.deceasedage.ForeColor = System.Drawing.Color.Black
        Me.deceasedage.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.deceasedage.Location = New System.Drawing.Point(376, 330)
        Me.deceasedage.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.deceasedage.Name = "deceasedage"
        Me.deceasedage.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.deceasedage.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.deceasedage.PlaceholderText = "Age"
        Me.deceasedage.SelectedText = ""
        Me.deceasedage.Size = New System.Drawing.Size(65, 38)
        Me.deceasedage.TabIndex = 241
        '
        'Label23
        '
        Me.Label23.AutoSize = True
        Me.Label23.Font = New System.Drawing.Font("Candara", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label23.Location = New System.Drawing.Point(393, 372)
        Me.Label23.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(32, 17)
        Me.Label23.TabIndex = 240
        Me.Label23.Text = "Age"
        '
        'namedeceased
        '
        Me.namedeceased.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.namedeceased.DefaultText = ""
        Me.namedeceased.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.namedeceased.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.namedeceased.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.namedeceased.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.namedeceased.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.namedeceased.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me.namedeceased.ForeColor = System.Drawing.Color.Black
        Me.namedeceased.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.namedeceased.Location = New System.Drawing.Point(22, 330)
        Me.namedeceased.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.namedeceased.Name = "namedeceased"
        Me.namedeceased.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.namedeceased.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.namedeceased.PlaceholderText = "Complete Name"
        Me.namedeceased.SelectedText = ""
        Me.namedeceased.Size = New System.Drawing.Size(333, 38)
        Me.namedeceased.TabIndex = 239
        '
        'Guna2HtmlLabel2
        '
        Me.Guna2HtmlLabel2.AutoSize = False
        Me.Guna2HtmlLabel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.Guna2HtmlLabel2.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel2.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Guna2HtmlLabel2.Location = New System.Drawing.Point(11, 282)
        Me.Guna2HtmlLabel2.Name = "Guna2HtmlLabel2"
        Me.Guna2HtmlLabel2.Size = New System.Drawing.Size(347, 41)
        Me.Guna2HtmlLabel2.TabIndex = 238
        Me.Guna2HtmlLabel2.Text = "Deceased Information"
        Me.Guna2HtmlLabel2.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        '
        'relationship
        '
        Me.relationship.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.relationship.DefaultText = ""
        Me.relationship.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.relationship.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.relationship.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.relationship.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.relationship.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.relationship.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me.relationship.ForeColor = System.Drawing.Color.Black
        Me.relationship.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.relationship.Location = New System.Drawing.Point(22, 204)
        Me.relationship.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.relationship.Name = "relationship"
        Me.relationship.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.relationship.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.relationship.PlaceholderText = "Relationship"
        Me.relationship.SelectedText = ""
        Me.relationship.Size = New System.Drawing.Size(419, 35)
        Me.relationship.TabIndex = 237
        '
        'Guna2HtmlLabel1
        '
        Me.Guna2HtmlLabel1.AutoSize = False
        Me.Guna2HtmlLabel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.Guna2HtmlLabel1.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Guna2HtmlLabel1.Location = New System.Drawing.Point(21, 18)
        Me.Guna2HtmlLabel1.Name = "Guna2HtmlLabel1"
        Me.Guna2HtmlLabel1.Size = New System.Drawing.Size(338, 43)
        Me.Guna2HtmlLabel1.TabIndex = 236
        Me.Guna2HtmlLabel1.Text = "Client Information"
        Me.Guna2HtmlLabel1.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Candara", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(25, 179)
        Me.Label3.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(117, 17)
        Me.Label3.TabIndex = 235
        Me.Label3.Text = "Complete Address"
        '
        'contactnumber
        '
        Me.contactnumber.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.contactnumber.DefaultText = ""
        Me.contactnumber.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.contactnumber.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.contactnumber.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.contactnumber.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.contactnumber.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.contactnumber.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me.contactnumber.ForeColor = System.Drawing.Color.Black
        Me.contactnumber.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.contactnumber.Location = New System.Drawing.Point(475, 67)
        Me.contactnumber.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.contactnumber.Name = "contactnumber"
        Me.contactnumber.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.contactnumber.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.contactnumber.PlaceholderText = "Contact Number"
        Me.contactnumber.SelectedText = ""
        Me.contactnumber.Size = New System.Drawing.Size(268, 41)
        Me.contactnumber.TabIndex = 234
        '
        'address
        '
        Me.address.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.address.DefaultText = ""
        Me.address.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.address.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.address.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.address.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.address.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.address.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me.address.ForeColor = System.Drawing.Color.Black
        Me.address.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.address.Location = New System.Drawing.Point(22, 137)
        Me.address.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.address.Name = "address"
        Me.address.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.address.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.address.PlaceholderText = "Complete Address"
        Me.address.SelectedText = ""
        Me.address.Size = New System.Drawing.Size(580, 38)
        Me.address.TabIndex = 233
        '
        'age
        '
        Me.age.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.age.DefaultText = ""
        Me.age.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.age.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.age.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.age.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.age.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.age.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold)
        Me.age.ForeColor = System.Drawing.Color.Black
        Me.age.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.age.Location = New System.Drawing.Point(376, 67)
        Me.age.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.age.Name = "age"
        Me.age.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.age.PlaceholderForeColor = System.Drawing.Color.DarkGray
        Me.age.PlaceholderText = "Age"
        Me.age.SelectedText = ""
        Me.age.Size = New System.Drawing.Size(65, 41)
        Me.age.TabIndex = 232
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Candara", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(482, 112)
        Me.Label5.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(106, 17)
        Me.Label5.TabIndex = 229
        Me.Label5.Text = "Contact Number"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Candara", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(393, 112)
        Me.Label6.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(32, 17)
        Me.Label6.TabIndex = 230
        Me.Label6.Text = "Age"
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Candara", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(31, 111)
        Me.Label7.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(102, 20)
        Me.Label7.TabIndex = 231
        Me.Label7.Text = "Client Name"
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Candara", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(510, 372)
        Me.Label14.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(64, 17)
        Me.Label14.TabIndex = 224
        Me.Label14.Text = "Birthdate"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Candara", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(782, 373)
        Me.Label12.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(91, 17)
        Me.Label12.TabIndex = 228
        Me.Label12.Text = "Date of Death"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Candara", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(25, 372)
        Me.Label11.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(118, 17)
        Me.Label11.TabIndex = 225
        Me.Label11.Text = "Name of Deceased"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Candara", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(791, 110)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(107, 17)
        Me.Label8.TabIndex = 226
        Me.Label8.Text = "Date of Contract"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Candara", 10.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(31, 243)
        Me.Label4.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(181, 17)
        Me.Label4.TabIndex = 227
        Me.Label4.Text = "Relationship to the Deceased"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Candara", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.Control
        Me.Label1.Location = New System.Drawing.Point(12, 8)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(301, 39)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "Contract Information"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(968, 71)
        Me.Panel1.TabIndex = 0
        '
        'ContractInformation
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 19.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(968, 672)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel1)
        Me.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "ContractInformation"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "ContractInformation"
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.adminSigPic, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.clientSigPic, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.Panel1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Panel2 As Panel
    Friend WithEvents clientName_CB As ComboBox
    Friend WithEvents Label10 As Label
    Friend WithEvents clientSigPic As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents uploadClientSig_bttn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents datecontract As Guna.UI2.WinForms.Guna2DateTimePicker
    Friend WithEvents deceasedbirthdate As Guna.UI2.WinForms.Guna2DateTimePicker
    Friend WithEvents deceaseddatedeath As Guna.UI2.WinForms.Guna2DateTimePicker
    Friend WithEvents Label24 As Label
    Friend WithEvents deceasedaddress As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents deceasedage As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Label23 As Label
    Friend WithEvents namedeceased As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel2 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents relationship As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Guna2HtmlLabel1 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Label3 As Label
    Friend WithEvents contactnumber As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents address As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents age As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents save_bttn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents adminSigPic As Guna.UI2.WinForms.Guna2PictureBox
    Friend WithEvents uploadAuthorizedSig_bttn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents totalamount As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Label17 As Label
    Friend WithEvents selectPackages As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Label1 As Label
    Friend WithEvents Panel1 As Panel
    Friend WithEvents deceasedID_TB As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents clientID_TB As Guna.UI2.WinForms.Guna2TextBox
End Class
