﻿Imports MySql.Data.MySqlClient
Imports System.IO
Public Class ContractInformation

    Dim ms As New System.IO.MemoryStream
    Dim opF As New OpenFileDialog

    Private Sub selectPackages_Click(sender As Object, e As EventArgs) Handles selectPackages.Click
        Packages.Show()
    End Sub


    Private Sub ContractInformation_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        auto_suggest("Client_Name", "contract_client", clientName_CB)

        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
        conn.Open()
        dtadapter = New MySqlDataAdapter("SELECT * FROM contract_client", conn)
        dataSet = New DataSet
        dtadapter.Fill(dataSet, "contract_client")
        Dim count As Integer = dataSet.Tables("contract_client").Rows.Count
        Dim x As Integer
        For x = 0 To count - 1
            clientName_CB.Items.Add(dataSet.Tables("contract_client").Rows(x).Item("Client_Name"))
        Next

    End Sub
    Private Sub clientName_CB_SelectedIndexChanged(sender As Object, e As EventArgs) Handles clientName_CB.SelectedIndexChanged
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
        conn.Open()
        cmd = conn.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT * FROM contract_client WHERE Client_Name='" & clientName_CB.Text & "'"
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New MySqlDataAdapter(cmd)
        da.Fill(dt)
        Dim dr As MySqlDataReader
        dr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
        While dr.Read
            clientID_TB.Text = dr.GetString(0).ToString()
            age.Text = dr.GetString(3).ToString()
            contactnumber.Text = dr.GetString(4).ToString()
            address.Text = dr.GetString(5).ToString()
        End While

    End Sub

    Private Sub uploadClientSig_bttn_Click(sender As Object, e As EventArgs) Handles uploadClientSig_bttn.Click
        opF.Filter = "Choose Image(*.jpg;*.png;*.gif)|*.jpg;*.png;*.gif"
        If opF.ShowDialog = DialogResult.OK Then
            clientSigPic.Image = Image.FromFile(opF.FileName)
        End If
    End Sub

    Private Sub uploadAuthorizedSig_bttn_Click(sender As Object, e As EventArgs) Handles uploadAuthorizedSig_bttn.Click
        opF.Filter = "Choose Image(*.jpg;*.png;*.gif)|*.jpg;*.png;*.gif"
        If opF.ShowDialog = DialogResult.OK Then
            adminSigPic.Image = Image.FromFile(opF.FileName)
        End If
    End Sub
    Private Sub datecontract_ValueChanged(sender As Object, e As EventArgs) Handles datecontract.ValueChanged
        datecontract.Format = DateTimePickerFormat.Custom
        datecontract.CustomFormat = "yyyy/MM/dd"
    End Sub
    Private Sub deceasedbirthdate_ValueChanged(sender As Object, e As EventArgs) Handles deceasedbirthdate.ValueChanged
        deceasedbirthdate.Format = DateTimePickerFormat.Custom
        deceasedbirthdate.CustomFormat = "yyyy/MM/dd"
    End Sub
    Private Sub deceaseddatedeath_ValueChanged(sender As Object, e As EventArgs) Handles deceaseddatedeath.ValueChanged
        deceaseddatedeath.Format = DateTimePickerFormat.Custom
        deceaseddatedeath.CustomFormat = "yyyy/MM/dd"
    End Sub
    Private Sub save_bttn_Click(sender As Object, e As EventArgs) Handles save_bttn.Click
        Dim ClientSigCMD As New MySqlCommand("UPDATE contract_client SET `Contractee_Signature`=@clientSig WHERE `Client_Name`='" & clientName_CB.Text & "'", conn)
        Dim AdminSigCMD As New MySqlCommand("UPDATE admin SET `Authorized_Signature`=@adminSig WHERE `Admin_ID`=1", conn)
        '  Dim AdminSigCMD As New MySqlCommand("INSERT INTO admin (`Authorized_Signature`) VALUES (@adminSig)", conn)
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
        conn.Open()
        cmd = conn.CreateCommand()
        'Updating Client Info

        cmd.CommandText = "UPDATE contract_client SET `Relationship_to_the_Deceased`='" & relationship.Text & "',`Date`='" & datecontract.Text & "' WHERE `Client_Name`='" & clientName_CB.Text & "';
        INSERT INTO deceased_information (`Client_ID`,`Name_of_Deceased`,`Date_of_Death`,`Age`,`Birthdate`,`Complete_Address`) VALUES ('" & clientID_TB.Text & "','" & namedeceased.Text & "','" & deceaseddatedeath.Text & "','" & deceasedage.Text & "','" & deceasedbirthdate.Text & "','" & deceasedaddress.Text & "')"

        'UPDATE contract_client SET `Relationship_to_the_Deceased`='" & relationship.Text & "', `Date`='" & datecontract.Text & "' WHERE `Client_Name`='" & clientName_CB.Text & "';
        'INSERT INTO deceased_information (`Name_of_Deceased`,`Date_of_Death`,`Age`,`Birthdate`,`Complete_Address` VALUES '" & namedeceased.Text & "','" & deceaseddatedeath.Text & "','" & age.Text & "','" & deceasedbirthdate.Text & "','" & deceasedaddress.Text & "' WHERE `Client_Name`='" & clientName_CB.Text & "' FROM contract_client";

        'Inserting Image
        clientSigPic.Image.Save(ms, clientSigPic.Image.RawFormat)
        adminSigPic.Image.Save(ms, adminSigPic.Image.RawFormat)
        ClientSigCMD.Parameters.Add("@clientSig", MySqlDbType.LongBlob).Value = ms.ToArray()
        AdminSigCMD.Parameters.Add("@adminSig", MySqlDbType.LongBlob).Value = ms.ToArray()
        ClientSigCMD.ExecuteNonQuery()
        AdminSigCMD.ExecuteNonQuery()
        If cmd.ExecuteNonQuery() Then
            MessageBox.Show("You Good")
        Else
            MessageBox.Show("There was a Problem!")
        End If


    End Sub


End Class