﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Packages
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.save_bttn = New Guna.UI2.WinForms.Guna2Button()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.typeOfPackage = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.freechapel_TB = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Internment_TB = New Guna.UI2.WinForms.Guna2TextBox()
        Me.wakeviewing_TB = New Guna.UI2.WinForms.Guna2TextBox()
        Me.embalming_TB = New Guna.UI2.WinForms.Guna2TextBox()
        Me.totalamount_TB = New Guna.UI2.WinForms.Guna2TextBox()
        Me.karwahe_TB = New Guna.UI2.WinForms.Guna2TextBox()
        Me.coffee_TB = New Guna.UI2.WinForms.Guna2TextBox()
        Me.gardenviewing_TB = New Guna.UI2.WinForms.Guna2TextBox()
        Me.roses_TB = New Guna.UI2.WinForms.Guna2TextBox()
        Me.balloons_TB = New Guna.UI2.WinForms.Guna2TextBox()
        Me.tribute_TB = New Guna.UI2.WinForms.Guna2TextBox()
        Me.picture_TB = New Guna.UI2.WinForms.Guna2TextBox()
        Me.flower_TB = New Guna.UI2.WinForms.Guna2TextBox()
        Me.tarpulin_TB = New Guna.UI2.WinForms.Guna2TextBox()
        Me.karwahe_CB = New Guna.UI2.WinForms.Guna2CheckBox()
        Me.coffee_CB = New Guna.UI2.WinForms.Guna2CheckBox()
        Me.gardenviewing_CB = New Guna.UI2.WinForms.Guna2CheckBox()
        Me.roses_CB = New Guna.UI2.WinForms.Guna2CheckBox()
        Me.balloons_CB = New Guna.UI2.WinForms.Guna2CheckBox()
        Me.tribute_CB = New Guna.UI2.WinForms.Guna2CheckBox()
        Me.pictureframe_CB = New Guna.UI2.WinForms.Guna2CheckBox()
        Me.flower_CB = New Guna.UI2.WinForms.Guna2CheckBox()
        Me.tarpulin_CB = New Guna.UI2.WinForms.Guna2CheckBox()
        Me.totalamount_services = New Guna.UI2.WinForms.Guna2TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'save_bttn
        '
        Me.save_bttn.BackColor = System.Drawing.Color.FromArgb(CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer), CType(CType(224, Byte), Integer))
        Me.save_bttn.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.save_bttn.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.save_bttn.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.save_bttn.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.save_bttn.FillColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.save_bttn.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.save_bttn.ForeColor = System.Drawing.Color.White
        Me.save_bttn.Location = New System.Drawing.Point(740, 557)
        Me.save_bttn.Name = "save_bttn"
        Me.save_bttn.Size = New System.Drawing.Size(160, 45)
        Me.save_bttn.TabIndex = 74
        Me.save_bttn.Text = "Save"
        '
        'Label6
        '
        Me.Label6.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(492, 200)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(119, 24)
        Me.Label6.TabIndex = 73
        Me.Label6.Text = "Free Chapel"
        '
        'Label5
        '
        Me.Label5.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(496, 149)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(119, 24)
        Me.Label5.TabIndex = 72
        Me.Label5.Text = "Internment"
        '
        'Label4
        '
        Me.Label4.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(95, 188)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(133, 24)
        Me.Label4.TabIndex = 71
        Me.Label4.Text = "Wake Viewing"
        '
        'Label3
        '
        Me.Label3.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(95, 137)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(118, 24)
        Me.Label3.TabIndex = 70
        Me.Label3.Text = "Embalming "
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Candara", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(508, 501)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(145, 28)
        Me.Label2.TabIndex = 65
        Me.Label2.Text = "Total Amount"
        '
        'typeOfPackage
        '
        Me.typeOfPackage.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.typeOfPackage.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.CustomSource
        Me.typeOfPackage.Font = New System.Drawing.Font("Candara", 16.2!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.typeOfPackage.FormattingEnabled = True
        Me.typeOfPackage.Location = New System.Drawing.Point(282, 66)
        Me.typeOfPackage.Name = "typeOfPackage"
        Me.typeOfPackage.Size = New System.Drawing.Size(402, 41)
        Me.typeOfPackage.TabIndex = 54
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.Label1.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label1.Location = New System.Drawing.Point(0, 246)
        Me.Label1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Padding = New System.Windows.Forms.Padding(30, 0, 0, 0)
        Me.Label1.Size = New System.Drawing.Size(296, 49)
        Me.Label1.TabIndex = 44
        Me.Label1.Text = "Ads On:"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label7
        '
        Me.Label7.Font = New System.Drawing.Font("Century Gothic", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(88, 76)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(188, 24)
        Me.Label7.TabIndex = 75
        Me.Label7.Text = "Type Of Package:"
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.Label8.Dock = System.Windows.Forms.DockStyle.Top
        Me.Label8.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label8.Location = New System.Drawing.Point(0, 0)
        Me.Label8.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.Label8.Name = "Label8"
        Me.Label8.Padding = New System.Windows.Forms.Padding(30, 0, 0, 0)
        Me.Label8.Size = New System.Drawing.Size(950, 49)
        Me.Label8.TabIndex = 76
        Me.Label8.Text = "Packages"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'freechapel_TB
        '
        Me.freechapel_TB.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.freechapel_TB.DefaultText = ""
        Me.freechapel_TB.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.freechapel_TB.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.freechapel_TB.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.freechapel_TB.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.freechapel_TB.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.freechapel_TB.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.freechapel_TB.ForeColor = System.Drawing.Color.Black
        Me.freechapel_TB.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.freechapel_TB.Location = New System.Drawing.Point(682, 200)
        Me.freechapel_TB.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.freechapel_TB.Name = "freechapel_TB"
        Me.freechapel_TB.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.freechapel_TB.PlaceholderText = ""
        Me.freechapel_TB.SelectedText = ""
        Me.freechapel_TB.Size = New System.Drawing.Size(160, 36)
        Me.freechapel_TB.TabIndex = 99
        '
        'Internment_TB
        '
        Me.Internment_TB.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.Internment_TB.DefaultText = ""
        Me.Internment_TB.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.Internment_TB.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.Internment_TB.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Internment_TB.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.Internment_TB.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Internment_TB.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Internment_TB.ForeColor = System.Drawing.Color.Black
        Me.Internment_TB.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Internment_TB.Location = New System.Drawing.Point(682, 137)
        Me.Internment_TB.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.Internment_TB.Name = "Internment_TB"
        Me.Internment_TB.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.Internment_TB.PlaceholderText = ""
        Me.Internment_TB.SelectedText = ""
        Me.Internment_TB.Size = New System.Drawing.Size(160, 36)
        Me.Internment_TB.TabIndex = 98
        '
        'wakeviewing_TB
        '
        Me.wakeviewing_TB.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.wakeviewing_TB.DefaultText = ""
        Me.wakeviewing_TB.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.wakeviewing_TB.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.wakeviewing_TB.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.wakeviewing_TB.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.wakeviewing_TB.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.wakeviewing_TB.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.wakeviewing_TB.ForeColor = System.Drawing.Color.Black
        Me.wakeviewing_TB.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.wakeviewing_TB.Location = New System.Drawing.Point(282, 188)
        Me.wakeviewing_TB.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.wakeviewing_TB.Name = "wakeviewing_TB"
        Me.wakeviewing_TB.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.wakeviewing_TB.PlaceholderText = ""
        Me.wakeviewing_TB.SelectedText = ""
        Me.wakeviewing_TB.Size = New System.Drawing.Size(160, 36)
        Me.wakeviewing_TB.TabIndex = 97
        '
        'embalming_TB
        '
        Me.embalming_TB.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.embalming_TB.DefaultText = ""
        Me.embalming_TB.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.embalming_TB.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.embalming_TB.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.embalming_TB.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.embalming_TB.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.embalming_TB.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.embalming_TB.ForeColor = System.Drawing.Color.Black
        Me.embalming_TB.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.embalming_TB.Location = New System.Drawing.Point(282, 137)
        Me.embalming_TB.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.embalming_TB.Name = "embalming_TB"
        Me.embalming_TB.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.embalming_TB.PlaceholderText = ""
        Me.embalming_TB.SelectedText = ""
        Me.embalming_TB.Size = New System.Drawing.Size(160, 36)
        Me.embalming_TB.TabIndex = 96
        '
        'totalamount_TB
        '
        Me.totalamount_TB.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.totalamount_TB.DefaultText = ""
        Me.totalamount_TB.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.totalamount_TB.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.totalamount_TB.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.totalamount_TB.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.totalamount_TB.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.totalamount_TB.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.totalamount_TB.ForeColor = System.Drawing.Color.Black
        Me.totalamount_TB.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.totalamount_TB.Location = New System.Drawing.Point(682, 493)
        Me.totalamount_TB.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.totalamount_TB.Name = "totalamount_TB"
        Me.totalamount_TB.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.totalamount_TB.PlaceholderText = ""
        Me.totalamount_TB.SelectedText = ""
        Me.totalamount_TB.Size = New System.Drawing.Size(160, 36)
        Me.totalamount_TB.TabIndex = 95
        '
        'karwahe_TB
        '
        Me.karwahe_TB.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.karwahe_TB.DefaultText = ""
        Me.karwahe_TB.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.karwahe_TB.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.karwahe_TB.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.karwahe_TB.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.karwahe_TB.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.karwahe_TB.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.karwahe_TB.ForeColor = System.Drawing.Color.Black
        Me.karwahe_TB.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.karwahe_TB.Location = New System.Drawing.Point(682, 448)
        Me.karwahe_TB.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.karwahe_TB.Name = "karwahe_TB"
        Me.karwahe_TB.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.karwahe_TB.PlaceholderText = ""
        Me.karwahe_TB.SelectedText = ""
        Me.karwahe_TB.Size = New System.Drawing.Size(160, 36)
        Me.karwahe_TB.TabIndex = 94
        '
        'coffee_TB
        '
        Me.coffee_TB.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.coffee_TB.DefaultText = ""
        Me.coffee_TB.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.coffee_TB.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.coffee_TB.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.coffee_TB.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.coffee_TB.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.coffee_TB.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.coffee_TB.ForeColor = System.Drawing.Color.Black
        Me.coffee_TB.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.coffee_TB.Location = New System.Drawing.Point(682, 402)
        Me.coffee_TB.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.coffee_TB.Name = "coffee_TB"
        Me.coffee_TB.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.coffee_TB.PlaceholderText = ""
        Me.coffee_TB.SelectedText = ""
        Me.coffee_TB.Size = New System.Drawing.Size(160, 36)
        Me.coffee_TB.TabIndex = 93
        '
        'gardenviewing_TB
        '
        Me.gardenviewing_TB.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.gardenviewing_TB.DefaultText = ""
        Me.gardenviewing_TB.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.gardenviewing_TB.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.gardenviewing_TB.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.gardenviewing_TB.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.gardenviewing_TB.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.gardenviewing_TB.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gardenviewing_TB.ForeColor = System.Drawing.Color.Black
        Me.gardenviewing_TB.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.gardenviewing_TB.Location = New System.Drawing.Point(682, 356)
        Me.gardenviewing_TB.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.gardenviewing_TB.Name = "gardenviewing_TB"
        Me.gardenviewing_TB.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.gardenviewing_TB.PlaceholderText = ""
        Me.gardenviewing_TB.SelectedText = ""
        Me.gardenviewing_TB.Size = New System.Drawing.Size(160, 36)
        Me.gardenviewing_TB.TabIndex = 92
        '
        'roses_TB
        '
        Me.roses_TB.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.roses_TB.DefaultText = ""
        Me.roses_TB.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.roses_TB.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.roses_TB.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.roses_TB.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.roses_TB.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.roses_TB.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.roses_TB.ForeColor = System.Drawing.Color.Black
        Me.roses_TB.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.roses_TB.Location = New System.Drawing.Point(682, 310)
        Me.roses_TB.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.roses_TB.Name = "roses_TB"
        Me.roses_TB.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.roses_TB.PlaceholderText = ""
        Me.roses_TB.SelectedText = ""
        Me.roses_TB.Size = New System.Drawing.Size(160, 36)
        Me.roses_TB.TabIndex = 91
        '
        'balloons_TB
        '
        Me.balloons_TB.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.balloons_TB.DefaultText = ""
        Me.balloons_TB.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.balloons_TB.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.balloons_TB.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.balloons_TB.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.balloons_TB.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.balloons_TB.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.balloons_TB.ForeColor = System.Drawing.Color.Black
        Me.balloons_TB.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.balloons_TB.Location = New System.Drawing.Point(282, 493)
        Me.balloons_TB.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.balloons_TB.Name = "balloons_TB"
        Me.balloons_TB.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.balloons_TB.PlaceholderText = ""
        Me.balloons_TB.SelectedText = ""
        Me.balloons_TB.Size = New System.Drawing.Size(160, 36)
        Me.balloons_TB.TabIndex = 90
        '
        'tribute_TB
        '
        Me.tribute_TB.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.tribute_TB.DefaultText = ""
        Me.tribute_TB.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.tribute_TB.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.tribute_TB.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.tribute_TB.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.tribute_TB.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.tribute_TB.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tribute_TB.ForeColor = System.Drawing.Color.Black
        Me.tribute_TB.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.tribute_TB.Location = New System.Drawing.Point(282, 448)
        Me.tribute_TB.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.tribute_TB.Name = "tribute_TB"
        Me.tribute_TB.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.tribute_TB.PlaceholderText = ""
        Me.tribute_TB.SelectedText = ""
        Me.tribute_TB.Size = New System.Drawing.Size(160, 36)
        Me.tribute_TB.TabIndex = 89
        '
        'picture_TB
        '
        Me.picture_TB.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.picture_TB.DefaultText = ""
        Me.picture_TB.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.picture_TB.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.picture_TB.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.picture_TB.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.picture_TB.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.picture_TB.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.picture_TB.ForeColor = System.Drawing.Color.Black
        Me.picture_TB.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.picture_TB.Location = New System.Drawing.Point(282, 402)
        Me.picture_TB.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.picture_TB.Name = "picture_TB"
        Me.picture_TB.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.picture_TB.PlaceholderText = ""
        Me.picture_TB.SelectedText = ""
        Me.picture_TB.Size = New System.Drawing.Size(160, 36)
        Me.picture_TB.TabIndex = 88
        '
        'flower_TB
        '
        Me.flower_TB.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.flower_TB.DefaultText = ""
        Me.flower_TB.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.flower_TB.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.flower_TB.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.flower_TB.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.flower_TB.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.flower_TB.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.flower_TB.ForeColor = System.Drawing.Color.Black
        Me.flower_TB.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.flower_TB.Location = New System.Drawing.Point(282, 356)
        Me.flower_TB.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.flower_TB.Name = "flower_TB"
        Me.flower_TB.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.flower_TB.PlaceholderText = ""
        Me.flower_TB.SelectedText = ""
        Me.flower_TB.Size = New System.Drawing.Size(160, 36)
        Me.flower_TB.TabIndex = 87
        '
        'tarpulin_TB
        '
        Me.tarpulin_TB.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.tarpulin_TB.DefaultText = ""
        Me.tarpulin_TB.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.tarpulin_TB.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.tarpulin_TB.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.tarpulin_TB.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.tarpulin_TB.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.tarpulin_TB.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.tarpulin_TB.ForeColor = System.Drawing.Color.Black
        Me.tarpulin_TB.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.tarpulin_TB.Location = New System.Drawing.Point(282, 310)
        Me.tarpulin_TB.Margin = New System.Windows.Forms.Padding(4, 4, 4, 4)
        Me.tarpulin_TB.Name = "tarpulin_TB"
        Me.tarpulin_TB.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.tarpulin_TB.PlaceholderText = ""
        Me.tarpulin_TB.SelectedText = ""
        Me.tarpulin_TB.Size = New System.Drawing.Size(160, 36)
        Me.tarpulin_TB.TabIndex = 86
        '
        'karwahe_CB
        '
        Me.karwahe_CB.AutoSize = True
        Me.karwahe_CB.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.karwahe_CB.CheckedState.BorderRadius = 0
        Me.karwahe_CB.CheckedState.BorderThickness = 0
        Me.karwahe_CB.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.karwahe_CB.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold)
        Me.karwahe_CB.Location = New System.Drawing.Point(500, 448)
        Me.karwahe_CB.Name = "karwahe_CB"
        Me.karwahe_CB.Size = New System.Drawing.Size(109, 28)
        Me.karwahe_CB.TabIndex = 85
        Me.karwahe_CB.Text = "Karwahe"
        Me.karwahe_CB.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.karwahe_CB.UncheckedState.BorderRadius = 0
        Me.karwahe_CB.UncheckedState.BorderThickness = 0
        Me.karwahe_CB.UncheckedState.FillColor = System.Drawing.Color.White
        '
        'coffee_CB
        '
        Me.coffee_CB.AutoSize = True
        Me.coffee_CB.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.coffee_CB.CheckedState.BorderRadius = 0
        Me.coffee_CB.CheckedState.BorderThickness = 0
        Me.coffee_CB.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.coffee_CB.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold)
        Me.coffee_CB.Location = New System.Drawing.Point(500, 402)
        Me.coffee_CB.Name = "coffee_CB"
        Me.coffee_CB.Size = New System.Drawing.Size(121, 28)
        Me.coffee_CB.TabIndex = 84
        Me.coffee_CB.Text = "Coffee Bar"
        Me.coffee_CB.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.coffee_CB.UncheckedState.BorderRadius = 0
        Me.coffee_CB.UncheckedState.BorderThickness = 0
        Me.coffee_CB.UncheckedState.FillColor = System.Drawing.Color.White
        '
        'gardenviewing_CB
        '
        Me.gardenviewing_CB.AutoSize = True
        Me.gardenviewing_CB.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.gardenviewing_CB.CheckedState.BorderRadius = 0
        Me.gardenviewing_CB.CheckedState.BorderThickness = 0
        Me.gardenviewing_CB.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.gardenviewing_CB.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold)
        Me.gardenviewing_CB.Location = New System.Drawing.Point(500, 364)
        Me.gardenviewing_CB.Name = "gardenviewing_CB"
        Me.gardenviewing_CB.Size = New System.Drawing.Size(167, 28)
        Me.gardenviewing_CB.TabIndex = 83
        Me.gardenviewing_CB.Text = "Garden Viewing"
        Me.gardenviewing_CB.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.gardenviewing_CB.UncheckedState.BorderRadius = 0
        Me.gardenviewing_CB.UncheckedState.BorderThickness = 0
        Me.gardenviewing_CB.UncheckedState.FillColor = System.Drawing.Color.White
        '
        'roses_CB
        '
        Me.roses_CB.AutoSize = True
        Me.roses_CB.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.roses_CB.CheckedState.BorderRadius = 0
        Me.roses_CB.CheckedState.BorderThickness = 0
        Me.roses_CB.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.roses_CB.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold)
        Me.roses_CB.Location = New System.Drawing.Point(500, 318)
        Me.roses_CB.Name = "roses_CB"
        Me.roses_CB.Size = New System.Drawing.Size(136, 28)
        Me.roses_CB.TabIndex = 82
        Me.roses_CB.Text = "White Roses"
        Me.roses_CB.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.roses_CB.UncheckedState.BorderRadius = 0
        Me.roses_CB.UncheckedState.BorderThickness = 0
        Me.roses_CB.UncheckedState.FillColor = System.Drawing.Color.White
        '
        'balloons_CB
        '
        Me.balloons_CB.AutoSize = True
        Me.balloons_CB.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.balloons_CB.CheckedState.BorderRadius = 0
        Me.balloons_CB.CheckedState.BorderThickness = 0
        Me.balloons_CB.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.balloons_CB.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold)
        Me.balloons_CB.Location = New System.Drawing.Point(49, 493)
        Me.balloons_CB.Name = "balloons_CB"
        Me.balloons_CB.Size = New System.Drawing.Size(147, 28)
        Me.balloons_CB.TabIndex = 81
        Me.balloons_CB.Text = "Free Balloons"
        Me.balloons_CB.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.balloons_CB.UncheckedState.BorderRadius = 0
        Me.balloons_CB.UncheckedState.BorderThickness = 0
        Me.balloons_CB.UncheckedState.FillColor = System.Drawing.Color.White
        '
        'tribute_CB
        '
        Me.tribute_CB.AutoSize = True
        Me.tribute_CB.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.tribute_CB.CheckedState.BorderRadius = 0
        Me.tribute_CB.CheckedState.BorderThickness = 0
        Me.tribute_CB.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.tribute_CB.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold)
        Me.tribute_CB.Location = New System.Drawing.Point(49, 448)
        Me.tribute_CB.Name = "tribute_CB"
        Me.tribute_CB.Size = New System.Drawing.Size(94, 28)
        Me.tribute_CB.TabIndex = 80
        Me.tribute_CB.Text = "Tribute"
        Me.tribute_CB.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.tribute_CB.UncheckedState.BorderRadius = 0
        Me.tribute_CB.UncheckedState.BorderThickness = 0
        Me.tribute_CB.UncheckedState.FillColor = System.Drawing.Color.White
        '
        'pictureframe_CB
        '
        Me.pictureframe_CB.AutoCheck = False
        Me.pictureframe_CB.AutoSize = True
        Me.pictureframe_CB.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.pictureframe_CB.CheckedState.BorderRadius = 0
        Me.pictureframe_CB.CheckedState.BorderThickness = 0
        Me.pictureframe_CB.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.pictureframe_CB.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold)
        Me.pictureframe_CB.Location = New System.Drawing.Point(49, 402)
        Me.pictureframe_CB.Name = "pictureframe_CB"
        Me.pictureframe_CB.Size = New System.Drawing.Size(152, 28)
        Me.pictureframe_CB.TabIndex = 79
        Me.pictureframe_CB.Text = "Picture Frame"
        Me.pictureframe_CB.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.pictureframe_CB.UncheckedState.BorderRadius = 0
        Me.pictureframe_CB.UncheckedState.BorderThickness = 0
        Me.pictureframe_CB.UncheckedState.FillColor = System.Drawing.Color.White
        '
        'flower_CB
        '
        Me.flower_CB.AutoCheck = False
        Me.flower_CB.AutoSize = True
        Me.flower_CB.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.flower_CB.CheckedState.BorderRadius = 0
        Me.flower_CB.CheckedState.BorderThickness = 0
        Me.flower_CB.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.flower_CB.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold)
        Me.flower_CB.Location = New System.Drawing.Point(49, 356)
        Me.flower_CB.Name = "flower_CB"
        Me.flower_CB.Size = New System.Drawing.Size(212, 28)
        Me.flower_CB.TabIndex = 78
        Me.flower_CB.Text = "Flower Arrangement"
        Me.flower_CB.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.flower_CB.UncheckedState.BorderRadius = 0
        Me.flower_CB.UncheckedState.BorderThickness = 0
        Me.flower_CB.UncheckedState.FillColor = System.Drawing.Color.White
        '
        'tarpulin_CB
        '
        Me.tarpulin_CB.AutoCheck = False
        Me.tarpulin_CB.AutoSize = True
        Me.tarpulin_CB.CheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.tarpulin_CB.CheckedState.BorderRadius = 0
        Me.tarpulin_CB.CheckedState.BorderThickness = 0
        Me.tarpulin_CB.CheckedState.FillColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.tarpulin_CB.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold)
        Me.tarpulin_CB.Location = New System.Drawing.Point(49, 310)
        Me.tarpulin_CB.Name = "tarpulin_CB"
        Me.tarpulin_CB.Size = New System.Drawing.Size(103, 28)
        Me.tarpulin_CB.TabIndex = 77
        Me.tarpulin_CB.Text = "Tarpulin"
        Me.tarpulin_CB.UncheckedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(125, Byte), Integer), CType(CType(137, Byte), Integer), CType(CType(149, Byte), Integer))
        Me.tarpulin_CB.UncheckedState.BorderRadius = 0
        Me.tarpulin_CB.UncheckedState.BorderThickness = 0
        Me.tarpulin_CB.UncheckedState.FillColor = System.Drawing.Color.White
        '
        'totalamount_services
        '
        Me.totalamount_services.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.totalamount_services.DefaultText = ""
        Me.totalamount_services.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.totalamount_services.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.totalamount_services.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.totalamount_services.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.totalamount_services.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.totalamount_services.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.totalamount_services.ForeColor = System.Drawing.Color.Black
        Me.totalamount_services.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.totalamount_services.Location = New System.Drawing.Point(692, 254)
        Me.totalamount_services.Margin = New System.Windows.Forms.Padding(5, 3, 5, 3)
        Me.totalamount_services.Name = "totalamount_services"
        Me.totalamount_services.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.totalamount_services.PlaceholderText = ""
        Me.totalamount_services.SelectedText = ""
        Me.totalamount_services.Size = New System.Drawing.Size(150, 41)
        Me.totalamount_services.TabIndex = 100
        Me.totalamount_services.Visible = False
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Candara", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(539, 267)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(145, 28)
        Me.Label9.TabIndex = 101
        Me.Label9.Text = "Total Amount"
        Me.Label9.Visible = False
        '
        'Packages
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(11.0!, 24.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(950, 625)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.totalamount_services)
        Me.Controls.Add(Me.freechapel_TB)
        Me.Controls.Add(Me.Internment_TB)
        Me.Controls.Add(Me.wakeviewing_TB)
        Me.Controls.Add(Me.embalming_TB)
        Me.Controls.Add(Me.totalamount_TB)
        Me.Controls.Add(Me.karwahe_TB)
        Me.Controls.Add(Me.coffee_TB)
        Me.Controls.Add(Me.gardenviewing_TB)
        Me.Controls.Add(Me.roses_TB)
        Me.Controls.Add(Me.balloons_TB)
        Me.Controls.Add(Me.tribute_TB)
        Me.Controls.Add(Me.picture_TB)
        Me.Controls.Add(Me.flower_TB)
        Me.Controls.Add(Me.tarpulin_TB)
        Me.Controls.Add(Me.karwahe_CB)
        Me.Controls.Add(Me.coffee_CB)
        Me.Controls.Add(Me.gardenviewing_CB)
        Me.Controls.Add(Me.roses_CB)
        Me.Controls.Add(Me.balloons_CB)
        Me.Controls.Add(Me.tribute_CB)
        Me.Controls.Add(Me.pictureframe_CB)
        Me.Controls.Add(Me.flower_CB)
        Me.Controls.Add(Me.tarpulin_CB)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.save_bttn)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.typeOfPackage)
        Me.Controls.Add(Me.Label1)
        Me.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "Packages"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Packages"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents save_bttn As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Label6 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents typeOfPackage As ComboBox
    Friend WithEvents Label1 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents freechapel_TB As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Internment_TB As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents wakeviewing_TB As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents embalming_TB As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents totalamount_TB As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents karwahe_TB As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents coffee_TB As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents gardenviewing_TB As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents roses_TB As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents balloons_TB As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents tribute_TB As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents picture_TB As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents flower_TB As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents tarpulin_TB As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents karwahe_CB As Guna.UI2.WinForms.Guna2CheckBox
    Friend WithEvents coffee_CB As Guna.UI2.WinForms.Guna2CheckBox
    Friend WithEvents gardenviewing_CB As Guna.UI2.WinForms.Guna2CheckBox
    Friend WithEvents roses_CB As Guna.UI2.WinForms.Guna2CheckBox
    Friend WithEvents balloons_CB As Guna.UI2.WinForms.Guna2CheckBox
    Friend WithEvents tribute_CB As Guna.UI2.WinForms.Guna2CheckBox
    Friend WithEvents pictureframe_CB As Guna.UI2.WinForms.Guna2CheckBox
    Friend WithEvents flower_CB As Guna.UI2.WinForms.Guna2CheckBox
    Friend WithEvents tarpulin_CB As Guna.UI2.WinForms.Guna2CheckBox
    Friend WithEvents totalamount_services As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents Label9 As Label
End Class
