﻿Imports MySql.Data.MySqlClient
Public Class Packages
    Dim con As String = "server=localhost;username=root;password=;database=stmartha_database"
    Dim mcon As New MySqlConnection
    Dim com As New MySqlCommand
    Dim reader As MySqlDataReader
    Private Sub Packages_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        auto_suggest("Package_Name", "packages", typeOfPackage)

        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
        conn.Open()
        dtadapter = New MySqlDataAdapter("SELECT * FROM packages", conn)
        dataSet = New DataSet
        dtadapter.Fill(dataSet, "packages")
        Dim count As Integer = dataSet.Tables("packages").Rows.Count
        Dim x As Integer
        For x = 0 To count - 1
            typeOfPackage.Items.Add(dataSet.Tables("packages").Rows(x).Item("Package_Name"))
        Next

    End Sub
    Private Sub typeOfPackage_SelectedIndexChanged(sender As Object, e As EventArgs) Handles typeOfPackage.SelectedIndexChanged
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
        conn.Open()
        cmd = conn.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT * FROM packages WHERE Package_Name='" & typeOfPackage.Text & "'"

        Select Case typeOfPackage.Text
            Case "Ordinary Casket"
                tarpulin_CB.Checked = CheckState.Checked
                flower_CB.Checked = CheckState.Checked
                pictureframe_CB.Checked = CheckState.Checked
                tribute_CB.Checked = CheckState.Unchecked
                balloons_CB.Checked = CheckState.Unchecked
                roses_CB.Checked = CheckState.Unchecked
                gardenviewing_CB.Checked = CheckState.Unchecked
                coffee_CB.Checked = CheckState.Unchecked
                karwahe_CB.Checked = CheckState.Unchecked
            Case "Round Top Casket"
                tarpulin_CB.Checked = CheckState.Checked
                flower_CB.Checked = CheckState.Checked
                pictureframe_CB.Checked = CheckState.Checked
                tribute_CB.Checked = CheckState.Unchecked
                balloons_CB.Checked = CheckState.Unchecked
                roses_CB.Checked = CheckState.Unchecked
                gardenviewing_CB.Checked = CheckState.Unchecked
                coffee_CB.Checked = CheckState.Unchecked
                karwahe_CB.Checked = CheckState.Unchecked
            Case "Ordinary Special"
                tarpulin_CB.Checked = CheckState.Checked
                flower_CB.Checked = CheckState.Checked
                pictureframe_CB.Checked = CheckState.Checked
                tribute_CB.Checked = CheckState.Unchecked
                balloons_CB.Checked = CheckState.Unchecked
                roses_CB.Checked = CheckState.Unchecked
                gardenviewing_CB.Checked = CheckState.Unchecked
                coffee_CB.Checked = CheckState.Unchecked
                karwahe_CB.Checked = CheckState.Unchecked
            Case "Ordinary Special Metal"
                tarpulin_CB.Checked = CheckState.Checked
                flower_CB.Checked = CheckState.Checked
                pictureframe_CB.Checked = CheckState.Checked
                tribute_CB.Checked = CheckState.Checked
                balloons_CB.Checked = CheckState.Checked
                roses_CB.Checked = CheckState.Checked
                gardenviewing_CB.Checked = CheckState.Unchecked
                coffee_CB.Checked = CheckState.Unchecked
                karwahe_CB.Checked = CheckState.Unchecked
            Case "OMB Half Glass Metal"
                tarpulin_CB.Checked = CheckState.Checked
                flower_CB.Checked = CheckState.Checked
                pictureframe_CB.Checked = CheckState.Checked
                tribute_CB.Checked = CheckState.Checked
                balloons_CB.Checked = CheckState.Checked
                roses_CB.Checked = CheckState.Checked
                gardenviewing_CB.Checked = CheckState.Unchecked
                coffee_CB.Checked = CheckState.Unchecked
                karwahe_CB.Checked = CheckState.Unchecked
            Case "OMB Full Glass Metal"
                tarpulin_CB.Checked = CheckState.Checked
                flower_CB.Checked = CheckState.Checked
                pictureframe_CB.Checked = CheckState.Checked
                tribute_CB.Checked = CheckState.Checked
                balloons_CB.Checked = CheckState.Checked
                roses_CB.Checked = CheckState.Checked
                gardenviewing_CB.Checked = CheckState.Unchecked
                coffee_CB.Checked = CheckState.Unchecked
                karwahe_CB.Checked = CheckState.Unchecked
            Case "Ordinary Metal"
                tarpulin_CB.Checked = CheckState.Checked
                flower_CB.Checked = CheckState.Checked
                pictureframe_CB.Checked = CheckState.Checked
                tribute_CB.Checked = CheckState.Checked
                balloons_CB.Checked = CheckState.Checked
                roses_CB.Checked = CheckState.Checked
                gardenviewing_CB.Checked = CheckState.Unchecked
                coffee_CB.Checked = CheckState.Unchecked
                karwahe_CB.Checked = CheckState.Unchecked
            Case "Full Cap"
                tarpulin_CB.Checked = CheckState.Checked
                flower_CB.Checked = CheckState.Checked
                pictureframe_CB.Checked = CheckState.Checked
                tribute_CB.Checked = CheckState.Checked
                balloons_CB.Checked = CheckState.Checked
                roses_CB.Checked = CheckState.Checked
                gardenviewing_CB.Checked = CheckState.Unchecked
                coffee_CB.Checked = CheckState.Unchecked
                karwahe_CB.Checked = CheckState.Unchecked
            Case "Junior Flexy Metal"
                tarpulin_CB.Checked = CheckState.Checked
                flower_CB.Checked = CheckState.Checked
                pictureframe_CB.Checked = CheckState.Checked
                tribute_CB.Checked = CheckState.Checked
                balloons_CB.Checked = CheckState.Checked
                roses_CB.Checked = CheckState.Checked
                gardenviewing_CB.Checked = CheckState.Checked
                coffee_CB.Checked = CheckState.Unchecked
                karwahe_CB.Checked = CheckState.Unchecked
            Case "Senior Flexy Metal"
                tarpulin_CB.Checked = CheckState.Checked
                flower_CB.Checked = CheckState.Checked
                pictureframe_CB.Checked = CheckState.Checked
                tribute_CB.Checked = CheckState.Checked
                balloons_CB.Checked = CheckState.Checked
                roses_CB.Checked = CheckState.Checked
                gardenviewing_CB.Checked = CheckState.Checked
                coffee_CB.Checked = CheckState.Checked
                karwahe_CB.Checked = CheckState.Checked
            Case "Jango Metal"
                tarpulin_CB.Checked = CheckState.Checked
                flower_CB.Checked = CheckState.Checked
                pictureframe_CB.Checked = CheckState.Checked
                tribute_CB.Checked = CheckState.Checked
                balloons_CB.Checked = CheckState.Checked
                roses_CB.Checked = CheckState.Checked
                gardenviewing_CB.Checked = CheckState.Checked
                coffee_CB.Checked = CheckState.Checked
                karwahe_CB.Checked = CheckState.Checked
            Case "Imported Metal Casket"
                tarpulin_CB.Checked = CheckState.Checked
                flower_CB.Checked = CheckState.Checked
                pictureframe_CB.Checked = CheckState.Checked
                tribute_CB.Checked = CheckState.Checked
                balloons_CB.Checked = CheckState.Checked
                roses_CB.Checked = CheckState.Checked
                gardenviewing_CB.Checked = CheckState.Checked
                coffee_CB.Checked = CheckState.Checked
                karwahe_CB.Checked = CheckState.Checked
            Case Else
                tarpulin_CB.Checked = CheckState.Unchecked
                flower_CB.Checked = CheckState.Unchecked
                pictureframe_CB.Checked = CheckState.Unchecked
                tribute_CB.Checked = CheckState.Unchecked
                balloons_CB.Checked = CheckState.Unchecked
                roses_CB.Checked = CheckState.Unchecked
                gardenviewing_CB.Checked = CheckState.Unchecked
                coffee_CB.Checked = CheckState.Unchecked
                karwahe_CB.Checked = CheckState.Unchecked
        End Select


        Dim dt As New DataTable()
        Dim da As New MySqlDataAdapter(cmd)

        reader = cmd.ExecuteReader(CommandBehavior.CloseConnection)
    End Sub

    Private Sub save_bttn_Click(sender As Object, e As EventArgs) Handles save_bttn.Click
        mcon.ConnectionString = con
        Try
            Dim checks = {tarpulin_CB, flower_CB, pictureframe_CB, tribute_CB, balloons_CB, roses_CB, gardenviewing_CB, coffee_CB, karwahe_CB}
            Dim selectedpackage As New List(Of String)
            For Each packageInclusion In checks
                If packageInclusion.Checked Then
                    selectedpackage.Add(packageInclusion.Text)
                End If
            Next
            Dim value = String.Join(",", selectedpackage.ToArray)
            mcon.Open()
            Dim save = "INSERT INTO add_packages(Package_Inclusions) VALUES('" & value & "')"
            com = New MySqlCommand(save, mcon)
            reader = com.ExecuteReader
            mcon.Close()
            reader.Close()
            MsgBox("Successully Added in Database", vbInformation)
            tarpulin_CB.Checked = False
            flower_CB.Checked = False
            pictureframe_CB.Checked = False
            tribute_CB.Checked = False
            balloons_CB.Checked = False
            roses_CB.Checked = False
            gardenviewing_CB.Checked = False
            coffee_CB.Checked = False
            karwahe_CB.Checked = False


        Catch ex As Exception
            MsgBox(ex.ToString)
        Finally
            mcon.Dispose()
        End Try

        '  Dim addonsCMD As New MySqlCommand
        ' Dim servicesCMD As New MySqlCommand
        ' ' addonsCMD = conn.CreateCommand()
        ' servicesCMD = conn.CreateCommand()
        ' servicesCMD.CommandText = "INSERT INTO `services`(`Embalming`, `Internment`, `Wake_Viewing`, `Free_Chapel`, `Total_Amount`) VALUES ('" & embalming_TB.Text & "','" & Internment_TB.Text & "','" & wakeviewing_TB.Text & "','" & freechapel_TB.Text & "','" & totalamount_services.Text & "')"
        ' addonsCMD.CommandText = "INSERT INTO `add_ons_price`(`Tarpaulin`, `Flower_Arrangement`, `Picture_Frame`, `Tribute`, `Free_Balloons`, `Roses`, `Garden_Viewing`, `Coffee_Bar`, `Karwahe`, `Total_Amount`) VALUES ('" & tarpulin_TB.Text & "','" & flower_TB.Text & "','" & picture_TB.Text & "','" & tribute_TB.Text & "','" & balloons_TB.Text & "','" & roses_TB.Text & "','" & gardenviewing_TB.Text & "','" & coffee_TB.Text & "','" & karwahe_TB.Text & "','" & totalamount_TB.Text & "')"
        ' addonsCMD.ExecuteNonQuery()
        '  servicesCMD.ExecuteNonQuery()

    End Sub

    Private Sub embalming_TB_TextChanged(sender As Object, e As EventArgs) Handles embalming_TB.TextChanged
        If embalming_TB.Text = "" Or wakeviewing_TB.Text = "" Or Internment_TB.Text = "" Or freechapel_TB.Text = "" Then
        Else
            Dim embalmingVal As Double = embalming_TB.Text
            Dim wakeviewingVal As Double = wakeviewing_TB.Text
            Dim internmentVal As Double = Internment_TB.Text
            Dim freechapelVal As Double = freechapel_TB.Text
            Dim servicestotal As Double = embalmingVal + embalmingVal + internmentVal + freechapelVal
            totalamount_services.Text = (FormatNumber(servicestotal))
        End If
    End Sub

    Private Sub wakeviewing_TB_TextChanged(sender As Object, e As EventArgs) Handles wakeviewing_TB.TextChanged
        If embalming_TB.Text = "" Or wakeviewing_TB.Text = "" Or Internment_TB.Text = "" Or freechapel_TB.Text = "" Then
        Else
            Dim embalmingVal As Double = embalming_TB.Text
            Dim wakeviewingVal As Double = wakeviewing_TB.Text
            Dim internmentVal As Double = Internment_TB.Text
            Dim freechapelVal As Double = freechapel_TB.Text
            Dim servicestotal As Double = embalmingVal + embalmingVal + internmentVal + freechapelVal
            totalamount_services.Text = (FormatNumber(servicestotal))
        End If
    End Sub

    Private Sub Internment_TB_TextChanged(sender As Object, e As EventArgs) Handles Internment_TB.TextChanged
        If embalming_TB.Text = "" Or wakeviewing_TB.Text = "" Or Internment_TB.Text = "" Or freechapel_TB.Text = "" Then
        Else
            Dim embalmingVal As Double = embalming_TB.Text
            Dim wakeviewingVal As Double = wakeviewing_TB.Text
            Dim internmentVal As Double = Internment_TB.Text
            Dim freechapelVal As Double = freechapel_TB.Text
            Dim servicestotal As Double = embalmingVal + embalmingVal + internmentVal + freechapelVal
            totalamount_services.Text = (FormatNumber(servicestotal))
        End If
    End Sub

    Private Sub freechapel_TB_TextChanged(sender As Object, e As EventArgs) Handles freechapel_TB.TextChanged
        If embalming_TB.Text = "" Or wakeviewing_TB.Text = "" Or Internment_TB.Text = "" Or freechapel_TB.Text = "" Then
        Else
            Dim embalmingVal As Double = embalming_TB.Text
            Dim wakeviewingVal As Double = wakeviewing_TB.Text
            Dim internmentVal As Double = Internment_TB.Text
            Dim freechapelVal As Double = freechapel_TB.Text
            Dim servicestotal As Double = embalmingVal + embalmingVal + internmentVal + freechapelVal
            totalamount_services.Text = (FormatNumber(servicestotal))
        End If
    End Sub

    Private Sub tarpulin_TB_TextChanged(sender As Object, e As EventArgs) Handles tarpulin_TB.TextChanged

        If tarpulin_TB.Text = "" Or flower_TB.Text = "" Or picture_TB.Text = "" Or tribute_TB.Text = "" Or balloons_TB.Text = "" Or roses_TB.Text = "" Or gardenviewing_TB.Text = "" Or coffee_TB.Text = "" Or karwahe_TB.Text = "" Then
        Else
            Dim tarpulinVal As Double = tarpulin_TB.Text
            Dim flowerVal As Double = flower_TB.Text
            Dim pictureVal As Double = picture_TB.Text
            Dim tributeVal As Double = tribute_TB.Text
            Dim ballonVal As Double = balloons_TB.Text
            Dim roseVal As Double = roses_TB.Text
            Dim gardenVal As Double = gardenviewing_TB.Text
            Dim coffeVal As Double = coffee_TB.Text
            Dim karwaheVal As Double = karwahe_TB.Text
            Dim addOnsTotal As Double = tarpulinVal + flowerVal
            totalamount_TB.Text = (FormatNumber(addOnsTotal))
        End If

    End Sub

    Private Sub flower_TB_TextChanged(sender As Object, e As EventArgs) Handles flower_TB.TextChanged
        If tarpulin_TB.Text = "" Or flower_TB.Text = "" Or picture_TB.Text = "" Or tribute_TB.Text = "" Or balloons_TB.Text = "" Or roses_TB.Text = "" Or gardenviewing_TB.Text = "" Or coffee_TB.Text = "" Or karwahe_TB.Text = "" Then
        Else
            Dim tarpulinVal As Double = tarpulin_TB.Text
            Dim flowerVal As Double = flower_TB.Text
            Dim pictureVal As Double = picture_TB.Text
            Dim tributeVal As Double = tribute_TB.Text
            Dim ballonVal As Double = balloons_TB.Text
            Dim roseVal As Double = roses_TB.Text
            Dim gardenVal As Double = gardenviewing_TB.Text
            Dim coffeVal As Double = coffee_TB.Text
            Dim karwaheVal As Double = karwahe_TB.Text
            Dim addOnsTotal As Double = tarpulinVal + flowerVal
            totalamount_TB.Text = (FormatNumber(addOnsTotal))
        End If
    End Sub

    Private Sub picture_TB_TextChanged(sender As Object, e As EventArgs) Handles picture_TB.TextChanged
        If tarpulin_TB.Text = "" Or flower_TB.Text = "" Or picture_TB.Text = "" Or tribute_TB.Text = "" Or balloons_TB.Text = "" Or roses_TB.Text = "" Or gardenviewing_TB.Text = "" Or coffee_TB.Text = "" Or karwahe_TB.Text = "" Then
        Else
            Dim tarpulinVal As Double = tarpulin_TB.Text
            Dim flowerVal As Double = flower_TB.Text
            Dim pictureVal As Double = picture_TB.Text
            Dim tributeVal As Double = tribute_TB.Text
            Dim ballonVal As Double = balloons_TB.Text
            Dim roseVal As Double = roses_TB.Text
            Dim gardenVal As Double = gardenviewing_TB.Text
            Dim coffeVal As Double = coffee_TB.Text
            Dim karwaheVal As Double = karwahe_TB.Text
            Dim addOnsTotal As Double = tarpulinVal + flowerVal + pictureVal
            totalamount_TB.Text = (FormatNumber(addOnsTotal))
        End If
    End Sub

    Private Sub tribute_TB_TextChanged(sender As Object, e As EventArgs) Handles tribute_TB.TextChanged
        If tarpulin_TB.Text = "" Or flower_TB.Text = "" Or picture_TB.Text = "" Or tribute_TB.Text = "" Or balloons_TB.Text = "" Or roses_TB.Text = "" Or gardenviewing_TB.Text = "" Or coffee_TB.Text = "" Or karwahe_TB.Text = "" Then
        Else
            Dim tarpulinVal As Double = tarpulin_TB.Text
            Dim flowerVal As Double = flower_TB.Text
            Dim pictureVal As Double = picture_TB.Text
            Dim tributeVal As Double = tribute_TB.Text
            Dim ballonVal As Double = balloons_TB.Text
            Dim roseVal As Double = roses_TB.Text
            Dim gardenVal As Double = gardenviewing_TB.Text
            Dim coffeVal As Double = coffee_TB.Text
            Dim karwaheVal As Double = karwahe_TB.Text
            Dim addOnsTotal As Double = tarpulinVal + flowerVal + pictureVal + tributeVal
            totalamount_TB.Text = (FormatNumber(addOnsTotal))
        End If
    End Sub

    Private Sub balloons_TB_TextChanged(sender As Object, e As EventArgs) Handles balloons_TB.TextChanged
        If tarpulin_TB.Text = "" Or flower_TB.Text = "" Or picture_TB.Text = "" Or tribute_TB.Text = "" Or balloons_TB.Text = "" Or roses_TB.Text = "" Or gardenviewing_TB.Text = "" Or coffee_TB.Text = "" Or karwahe_TB.Text = "" Then
        Else
            Dim tarpulinVal As Double = tarpulin_TB.Text
            Dim flowerVal As Double = flower_TB.Text
            Dim pictureVal As Double = picture_TB.Text
            Dim tributeVal As Double = tribute_TB.Text
            Dim ballonVal As Double = balloons_TB.Text
            Dim roseVal As Double = roses_TB.Text
            Dim gardenVal As Double = gardenviewing_TB.Text
            Dim coffeVal As Double = coffee_TB.Text
            Dim karwaheVal As Double = karwahe_TB.Text
            Dim addOnsTotal As Double = tarpulinVal + flowerVal + pictureVal + tributeVal + ballonVal
            totalamount_TB.Text = (FormatNumber(addOnsTotal))
        End If
    End Sub

    Private Sub roses_TB_TextChanged(sender As Object, e As EventArgs) Handles roses_TB.TextChanged
        If tarpulin_TB.Text = "" Or flower_TB.Text = "" Or picture_TB.Text = "" Or tribute_TB.Text = "" Or balloons_TB.Text = "" Or roses_TB.Text = "" Or gardenviewing_TB.Text = "" Or coffee_TB.Text = "" Or karwahe_TB.Text = "" Then
        Else
            Dim tarpulinVal As Double = tarpulin_TB.Text
            Dim flowerVal As Double = flower_TB.Text
            Dim pictureVal As Double = picture_TB.Text
            Dim tributeVal As Double = tribute_TB.Text
            Dim ballonVal As Double = balloons_TB.Text
            Dim roseVal As Double = roses_TB.Text
            Dim gardenVal As Double = gardenviewing_TB.Text
            Dim coffeVal As Double = coffee_TB.Text
            Dim karwaheVal As Double = karwahe_TB.Text
            Dim addOnsTotal As Double = tarpulinVal + flowerVal + pictureVal + tributeVal + ballonVal + roseVal
            totalamount_TB.Text = (FormatNumber(addOnsTotal))
        End If
    End Sub

    Private Sub gardenviewing_TB_TextChanged(sender As Object, e As EventArgs) Handles gardenviewing_TB.TextChanged
        If tarpulin_TB.Text = "" Or flower_TB.Text = "" Or picture_TB.Text = "" Or tribute_TB.Text = "" Or balloons_TB.Text = "" Or roses_TB.Text = "" Or gardenviewing_TB.Text = "" Or coffee_TB.Text = "" Or karwahe_TB.Text = "" Then
        Else
            Dim tarpulinVal As Double = tarpulin_TB.Text
            Dim flowerVal As Double = flower_TB.Text
            Dim pictureVal As Double = picture_TB.Text
            Dim tributeVal As Double = tribute_TB.Text
            Dim ballonVal As Double = balloons_TB.Text
            Dim roseVal As Double = roses_TB.Text
            Dim gardenVal As Double = gardenviewing_TB.Text
            Dim coffeVal As Double = coffee_TB.Text
            Dim karwaheVal As Double = karwahe_TB.Text
            Dim addOnsTotal As Double = tarpulinVal + flowerVal + pictureVal + tributeVal + ballonVal + roseVal + gardenVal
            totalamount_TB.Text = (FormatNumber(addOnsTotal))
        End If
    End Sub

    Private Sub coffee_TB_TextChanged(sender As Object, e As EventArgs) Handles coffee_TB.TextChanged
        If tarpulin_TB.Text = "" Or flower_TB.Text = "" Or picture_TB.Text = "" Or tribute_TB.Text = "" Or balloons_TB.Text = "" Or roses_TB.Text = "" Or gardenviewing_TB.Text = "" Or coffee_TB.Text = "" Or karwahe_TB.Text = "" Then
        Else
            Dim tarpulinVal As Double = tarpulin_TB.Text
            Dim flowerVal As Double = flower_TB.Text
            Dim pictureVal As Double = picture_TB.Text
            Dim tributeVal As Double = tribute_TB.Text
            Dim ballonVal As Double = balloons_TB.Text
            Dim roseVal As Double = roses_TB.Text
            Dim gardenVal As Double = gardenviewing_TB.Text
            Dim coffeVal As Double = coffee_TB.Text
            Dim karwaheVal As Double = karwahe_TB.Text
            Dim addOnsTotal As Double = tarpulinVal + flowerVal + pictureVal + tributeVal + ballonVal + roseVal + gardenVal + coffeVal
            totalamount_TB.Text = (FormatNumber(addOnsTotal))
        End If
    End Sub

    Private Sub karwahe_TB_TextChanged(sender As Object, e As EventArgs) Handles karwahe_TB.TextChanged
        If tarpulin_TB.Text = "" Or flower_TB.Text = "" Or picture_TB.Text = "" Or tribute_TB.Text = "" Or balloons_TB.Text = "" Or roses_TB.Text = "" Or gardenviewing_TB.Text = "" Or coffee_TB.Text = "" Or karwahe_TB.Text = "" Then
        Else
            Dim tarpulinVal As Double = tarpulin_TB.Text
            Dim flowerVal As Double = flower_TB.Text
            Dim pictureVal As Double = picture_TB.Text
            Dim tributeVal As Double = tribute_TB.Text
            Dim ballonVal As Double = balloons_TB.Text
            Dim roseVal As Double = roses_TB.Text
            Dim gardenVal As Double = gardenviewing_TB.Text
            Dim coffeVal As Double = coffee_TB.Text
            Dim karwaheVal As Double = karwahe_TB.Text
            Dim addOnsTotal As Double = tarpulinVal + flowerVal + pictureVal + tributeVal + ballonVal + roseVal + gardenVal + coffeVal + karwaheVal
            totalamount_TB.Text = (FormatNumber(addOnsTotal))
        End If
    End Sub
End Class