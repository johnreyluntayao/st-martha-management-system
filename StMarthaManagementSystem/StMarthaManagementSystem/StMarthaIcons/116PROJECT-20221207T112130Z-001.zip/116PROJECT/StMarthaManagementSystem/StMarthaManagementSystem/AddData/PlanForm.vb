﻿Public Class PlanForm
    Private Sub plan_bttn_Click(sender As Object, e As EventArgs) Handles plan_bttn.Click

    End Sub
End Class