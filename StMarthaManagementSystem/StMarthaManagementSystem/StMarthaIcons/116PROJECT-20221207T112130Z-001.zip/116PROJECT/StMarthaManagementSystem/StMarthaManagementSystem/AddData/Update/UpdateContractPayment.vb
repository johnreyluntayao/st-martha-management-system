﻿Public Class UpdateContractPayment





    Private Sub back_bttn_Click(sender As Object, e As EventArgs) Handles back_bttn.Click
        Me.Hide()
        ContractPaymentRecord.Show()
    End Sub
End Class