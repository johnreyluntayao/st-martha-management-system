﻿Imports MySql.Data.MySqlClient

Public Class UpdatePlanForm
    Dim id As String
    Private Sub Panel2_Paint(sender As Object, e As PaintEventArgs) Handles Panel2.Paint
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
        conn.Open()

        id = PlanRecord.planRecDGV.SelectedCells.Item(0).Value.ToString()
        cmd = conn.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT plan_client.Client_ID,plan_client.Client_Name,plan_client.Address,plan_client.Name_of_Trustee,plan.Plan_Name,plan.Installment_Payment,plan.Gross_Price,plan.Term,plan.Mode,plan.Due_Date FROM plan_client INNER JOIN plan ON plan_client.Client_ID = plan.Plan_ID WHERE Plan_ID='" & id & "'"
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New MySqlDataAdapter(cmd)
        da.Fill(dt)
        Dim dr As MySqlDataReader
        dr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
        While dr.Read

            Guna2TextBox1.Text = dr.GetString(1).ToString()
            Guna2TextBox2.Text = dr.GetString(2).ToString()
            Guna2TextBox7.Text = dr.GetString(3).ToString()
            Guna2TextBox3.Text = dr.GetString(4).ToString()
            Guna2TextBox5.Text = dr.GetString(5).ToString()
            Guna2TextBox6.Text = dr.GetString(6).ToString()
            Guna2TextBox9.Text = dr.GetString(7).ToString()
            Guna2TextBox8.Text = dr.GetString(8).ToString()
            Guna2DateTimePicker1.Text = dr.GetString(9).ToString()

            'ung radio button nalng kulang dito




        End While
    End Sub

    Private Sub back_bttn_Click(sender As Object, e As EventArgs) Handles back_bttn.Click
        Me.Hide()
        PlanRecord.Show()
    End Sub

    Private Sub Guna2Button1_Click(sender As Object, e As EventArgs) Handles Guna2Button1.Click
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
        conn.Open()
        Try
            id = PlanRecord.planRecDGV.SelectedCells.Item(0).Value.ToString()
            cmd.Connection = conn
            cmd.CommandText = "UPDATE plan_client INNER JOIN plan ON plan_client.Client_ID = plan.Plan_ID SET plan_client.Client_Name='" & Guna2TextBox1.Text & "',plan_client.Address='" & Guna2TextBox2.Text & "',plan_client.Name_of_Trustee='" & Guna2TextBox7.Text & "',plan.Plan_Name='" & Guna2TextBox3.Text & "',plan.Installment_Payment='" & Guna2TextBox5.Text & "',plan.Gross_Price='" & Guna2TextBox6.Text & "',plan.Term='" & Guna2TextBox9.Text & "',plan.Mode='" & Guna2TextBox8.Text & "',plan.Due_Date='" & Guna2DateTimePicker1.Text & "' WHERE plan_client.Client_ID = '" & id & "';"
            cmd.ExecuteNonQuery()


            MsgBox("Successfully Updated")
            Guna2TextBox1.Text = ""
            Guna2TextBox2.Text = ""
            Guna2TextBox7.Text = ""
            Guna2TextBox3.Text = ""
            Guna2TextBox5.Text = ""
            Guna2TextBox6.Text = ""
            Guna2TextBox9.Text = ""
            Guna2TextBox8.Text = ""
            Guna2DateTimePicker1.Text = ""
        Catch ex As Exception
            MsgBox(ex.ToString)

        End Try
    End Sub
End Class