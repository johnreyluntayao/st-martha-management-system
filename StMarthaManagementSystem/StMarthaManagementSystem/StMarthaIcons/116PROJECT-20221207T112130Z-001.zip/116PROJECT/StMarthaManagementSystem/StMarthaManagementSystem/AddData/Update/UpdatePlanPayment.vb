﻿Imports Guna.UI2.WinForms
Imports MySql.Data.MySqlClient

Public Class UpdatePlanPayment
    Dim id As String

    Private Sub Panel2_Paint(sender As Object, e As PaintEventArgs) Handles Panel2.Paint
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
        conn.Open()

        id = PlanPaymentRecord.planPaymentRecDGV.SelectedCells.Item(0).Value.ToString()
        cmd = conn.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT plan_client.Client_Name,plan_payment.Plan_ID,plan_payment.Month,plan_payment.Date,plan_payment.OR_No,plan_payment.Amount,plan_payment.Balance FROM plan_payment INNER JOIN plan ON plan_payment.Plan_Payment_ID = plan.Plan_ID INNER JOIN plan_client ON plan.Plan_ID = plan_client.Client_ID WHERE plan_payment.Plan_Payment_ID = '" & id & "'"
        'Ung Date ang problema
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New MySqlDataAdapter(cmd)
        da.Fill(dt)
        Dim dr As MySqlDataReader
        dr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
        While dr.Read

            Guna2TextBox1.Text = dr.GetString(0).ToString()
            Guna2TextBox4.Text = dr.GetString(1).ToString()
            Guna2TextBox6.Text = dr.GetString(2).ToString()
            Guna2DateTimePicker4.Text = dr.GetString(3).ToString()
            Guna2TextBox5.Text = dr.GetString(4).ToString()
            Guna2TextBox3.Text = dr.GetString(5).ToString()
            Guna2TextBox2.Text = dr.GetString(6).ToString()






        End While
    End Sub

    Private Sub back_bttn_Click(sender As Object, e As EventArgs) Handles back_bttn.Click
        Me.Hide()
        PlanPaymentRecord.Show()
    End Sub

    Private Sub Guna2Button1_Click(sender As Object, e As EventArgs) Handles Guna2Button1.Click
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
        conn.Open()
        Try
            id = PlanPaymentRecord.planPaymentRecDGV.SelectedCells.Item(0).Value.ToString()
            cmd.Connection = conn
            cmd.CommandText = "UPDATE plan_payment INNER JOIN plan ON plan_payment.Plan_Payment_ID = plan.Plan_ID INNER JOIN plan_client ON plan.Plan_ID = plan_client.Client_ID SET plan_client.Client_Name='" & Guna2TextBox1.Text & "',plan_payment.Plan_ID='" & Guna2TextBox4.Text & "',plan_payment.Month='" & Guna2TextBox6.Text & "',plan_payment.Date='" & Guna2DateTimePicker4.Text & "',plan_payment.OR_No='" & Guna2TextBox5.Text & "',plan_payment.Amount='" & Guna2TextBox3.Text & "',plan_payment.Balance='" & Guna2TextBox2.Text & "' WHERE plan_payment.Plan_Payment_ID='" & id & "'"
            cmd.ExecuteNonQuery()


            MsgBox("Successfully Updated")
            Guna2TextBox1.Text = ""
            Guna2TextBox4.Text = ""
            Guna2TextBox6.Text = ""
            Guna2TextBox5.Text = ""
            Guna2TextBox3.Text = ""
            Guna2TextBox2.Text = ""
        Catch ex As Exception
            MsgBox(ex.ToString)

        End Try
    End Sub
End Class