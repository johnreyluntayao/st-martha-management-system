﻿Imports MySql.Data.MySqlClient
Imports Org.BouncyCastle.Utilities.Collections
Imports System.Windows.Forms.VisualStyles.VisualStyleElement

Public Class UpdatedClientForm

    Dim id As String
    Private Sub Panel2_Paint(sender As Object, e As PaintEventArgs) Handles Panel2.Paint
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
        conn.Open()

        id = ClientRecord.clientRecDGV.SelectedCells.Item(0).Value.ToString()
        cmd = conn.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT Client_ID,Client_Name,Age,Contact_Number,Address,Gender FROM contract_client WHERE Client_ID='" & id & "'"
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New MySqlDataAdapter(cmd)
        da.Fill(dt)
        Dim dr As MySqlDataReader
        dr = cmd.ExecuteReader(CommandBehavior.CloseConnection)
        While dr.Read

            Guna2TextBox1.Text = dr.GetString(1).ToString()
            Guna2TextBox2.Text = dr.GetString(2).ToString()
            Guna2TextBox3.Text = dr.GetString(3).ToString()
            Guna2TextBox4.Text = dr.GetString(4).ToString()

            'ung radio button nalng kulang dito




        End While
    End Sub

    Public Sub disp_data()
        cmd = conn.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT Client_ID,Client_Name,Age,Contact_Number,Address,Gender FROM contract_client"
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New MySqlDataAdapter(cmd)
        da.Fill(dt)
        ClientRecord.clientRecDGV.DataSource = dt
    End Sub

    Private Sub back_bttn_Click(sender As Object, e As EventArgs) Handles back_bttn.Click
        Me.Hide()
        ClientRecord.Show()
    End Sub

    Private Sub Guna2Button3_Click(sender As Object, e As EventArgs) Handles Guna2Button3.Click
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
        conn.Open()
        Try
            id = ClientRecord.clientRecDGV.SelectedCells.Item(0).Value.ToString()
            cmd.Connection = conn
            cmd.CommandText = "UPDATE `contract_client` SET `Client_Name`='" & Guna2TextBox1.Text & "',`Age`='" & Guna2TextBox2.Text & "',`Address`='" & Guna2TextBox3.Text & "',`Contact_Number`='" & Guna2TextBox4.Text & "' WHERE `contract_client`.`Client_ID` = '" & id & "' "
            cmd.ExecuteNonQuery()
            disp_data()

            MsgBox("Successfully Updated")
            Guna2TextBox1.Text = ""
            Guna2TextBox2.Text = ""
            Guna2TextBox3.Text = ""
            Guna2TextBox4.Text = ""

        Catch ex As Exception
            MsgBox(ex.ToString)

        End Try
    End Sub
End Class