﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class DashboardFrame
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(DashboardFrame))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.MenuPanel = New System.Windows.Forms.Panel()
        Me.salesreport = New Guna.UI2.WinForms.Guna2Button()
        Me.records = New Guna.UI2.WinForms.Guna2Button()
        Me.regnewclient = New Guna.UI2.WinForms.Guna2Button()
        Me.dashboard = New Guna.UI2.WinForms.Guna2Button()
        Me.Logout = New Guna.UI2.WinForms.Guna2Button()
        Me.Guna2CircleButton2 = New Guna.UI2.WinForms.Guna2CircleButton()
        Me.Guna2DateTimePicker1 = New Guna.UI2.WinForms.Guna2DateTimePicker()
        Me.Guna2HtmlLabel1 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2GradientPanel1 = New Guna.UI2.WinForms.Guna2GradientPanel()
        Me.Guna2HtmlLabel2 = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Guna2GradientPanel2 = New Guna.UI2.WinForms.Guna2GradientPanel()
        Me.Guna2CircleButton1 = New Guna.UI2.WinForms.Guna2CircleButton()
        Me.countuser = New Guna.UI2.WinForms.Guna2HtmlLabel()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.close_bttn = New System.Windows.Forms.PictureBox()
        Me.Panel1.SuspendLayout()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.MenuPanel.SuspendLayout()
        Me.Guna2GradientPanel1.SuspendLayout()
        Me.Guna2GradientPanel2.SuspendLayout()
        Me.Panel2.SuspendLayout()
        CType(Me.close_bttn, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.ForeColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Label1.Location = New System.Drawing.Point(105, 25)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(152, 80)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "St. Martha" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Memorial Homes" & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Inc." & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10)
        '
        'Panel1
        '
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Controls.Add(Me.PictureBox1)
        Me.Panel1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Panel1.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel1.Location = New System.Drawing.Point(0, 0)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(262, 130)
        Me.Panel1.TabIndex = 0
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(5, 25)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(103, 80)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 2
        Me.PictureBox1.TabStop = False
        '
        'MenuPanel
        '
        Me.MenuPanel.BackColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.MenuPanel.Controls.Add(Me.salesreport)
        Me.MenuPanel.Controls.Add(Me.records)
        Me.MenuPanel.Controls.Add(Me.regnewclient)
        Me.MenuPanel.Controls.Add(Me.dashboard)
        Me.MenuPanel.Controls.Add(Me.Logout)
        Me.MenuPanel.Controls.Add(Me.Panel1)
        Me.MenuPanel.Dock = System.Windows.Forms.DockStyle.Left
        Me.MenuPanel.Location = New System.Drawing.Point(0, 0)
        Me.MenuPanel.Name = "MenuPanel"
        Me.MenuPanel.Size = New System.Drawing.Size(262, 700)
        Me.MenuPanel.TabIndex = 5
        '
        'salesreport
        '
        Me.salesreport.Cursor = System.Windows.Forms.Cursors.Hand
        Me.salesreport.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.salesreport.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.salesreport.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.salesreport.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.salesreport.Dock = System.Windows.Forms.DockStyle.Top
        Me.salesreport.FillColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.salesreport.Font = New System.Drawing.Font("Century Gothic", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.salesreport.ForeColor = System.Drawing.Color.White
        Me.salesreport.Image = Global.StMarthaManagementSystem.My.Resources.Resources.analysis__1_
        Me.salesreport.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.salesreport.ImageOffset = New System.Drawing.Point(18, 0)
        Me.salesreport.ImageSize = New System.Drawing.Size(35, 35)
        Me.salesreport.Location = New System.Drawing.Point(0, 364)
        Me.salesreport.Name = "salesreport"
        Me.salesreport.Padding = New System.Windows.Forms.Padding(0, 0, 15, 0)
        Me.salesreport.Size = New System.Drawing.Size(262, 78)
        Me.salesreport.TabIndex = 23
        Me.salesreport.Text = "Sales Report"
        Me.salesreport.TextOffset = New System.Drawing.Point(50, 0)
        '
        'records
        '
        Me.records.Cursor = System.Windows.Forms.Cursors.Hand
        Me.records.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.records.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.records.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.records.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.records.Dock = System.Windows.Forms.DockStyle.Top
        Me.records.FillColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.records.Font = New System.Drawing.Font("Century Gothic", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.records.ForeColor = System.Drawing.Color.White
        Me.records.Image = Global.StMarthaManagementSystem.My.Resources.Resources.edit
        Me.records.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.records.ImageOffset = New System.Drawing.Point(18, 0)
        Me.records.ImageSize = New System.Drawing.Size(35, 35)
        Me.records.Location = New System.Drawing.Point(0, 286)
        Me.records.Name = "records"
        Me.records.Padding = New System.Windows.Forms.Padding(0, 0, 15, 0)
        Me.records.Size = New System.Drawing.Size(262, 78)
        Me.records.TabIndex = 22
        Me.records.Text = "Records"
        Me.records.TextOffset = New System.Drawing.Point(50, 0)
        '
        'regnewclient
        '
        Me.regnewclient.Cursor = System.Windows.Forms.Cursors.Hand
        Me.regnewclient.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.regnewclient.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.regnewclient.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.regnewclient.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.regnewclient.Dock = System.Windows.Forms.DockStyle.Top
        Me.regnewclient.FillColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.regnewclient.Font = New System.Drawing.Font("Century Gothic", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.regnewclient.ForeColor = System.Drawing.Color.White
        Me.regnewclient.Image = Global.StMarthaManagementSystem.My.Resources.Resources.user
        Me.regnewclient.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.regnewclient.ImageOffset = New System.Drawing.Point(18, 0)
        Me.regnewclient.ImageSize = New System.Drawing.Size(35, 35)
        Me.regnewclient.Location = New System.Drawing.Point(0, 208)
        Me.regnewclient.Name = "regnewclient"
        Me.regnewclient.Padding = New System.Windows.Forms.Padding(0, 0, 15, 0)
        Me.regnewclient.Size = New System.Drawing.Size(262, 78)
        Me.regnewclient.TabIndex = 20
        Me.regnewclient.Text = "Register New Client"
        Me.regnewclient.TextOffset = New System.Drawing.Point(50, 0)
        '
        'dashboard
        '
        Me.dashboard.Cursor = System.Windows.Forms.Cursors.Hand
        Me.dashboard.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.dashboard.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.dashboard.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.dashboard.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.dashboard.Dock = System.Windows.Forms.DockStyle.Top
        Me.dashboard.FillColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.dashboard.Font = New System.Drawing.Font("Century Gothic", 10.2!, System.Drawing.FontStyle.Bold)
        Me.dashboard.ForeColor = System.Drawing.Color.White
        Me.dashboard.Image = Global.StMarthaManagementSystem.My.Resources.Resources.dashboard
        Me.dashboard.ImageAlign = System.Windows.Forms.HorizontalAlignment.Left
        Me.dashboard.ImageOffset = New System.Drawing.Point(18, 0)
        Me.dashboard.ImageSize = New System.Drawing.Size(35, 35)
        Me.dashboard.Location = New System.Drawing.Point(0, 130)
        Me.dashboard.Name = "dashboard"
        Me.dashboard.Padding = New System.Windows.Forms.Padding(0, 0, 15, 0)
        Me.dashboard.Size = New System.Drawing.Size(262, 78)
        Me.dashboard.TabIndex = 19
        Me.dashboard.Text = "Dashboard"
        Me.dashboard.TextOffset = New System.Drawing.Point(50, 0)
        '
        'Logout
        '
        Me.Logout.BorderRadius = 10
        Me.Logout.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.Logout.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.Logout.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Logout.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.Logout.FillColor = System.Drawing.SystemColors.Highlight
        Me.Logout.Font = New System.Drawing.Font("Candara", 12.0!)
        Me.Logout.ForeColor = System.Drawing.Color.Black
        Me.Logout.Image = CType(resources.GetObject("Logout.Image"), System.Drawing.Image)
        Me.Logout.ImageAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.Logout.ImageSize = New System.Drawing.Size(30, 30)
        Me.Logout.Location = New System.Drawing.Point(76, 595)
        Me.Logout.Name = "Logout"
        Me.Logout.Size = New System.Drawing.Size(138, 53)
        Me.Logout.TabIndex = 15
        Me.Logout.Text = "Log Out"
        Me.Logout.TextAlign = System.Windows.Forms.HorizontalAlignment.Left
        '
        'Guna2CircleButton2
        '
        Me.Guna2CircleButton2.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Guna2CircleButton2.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.Guna2CircleButton2.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.Guna2CircleButton2.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Guna2CircleButton2.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.Guna2CircleButton2.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2CircleButton2.ForeColor = System.Drawing.Color.White
        Me.Guna2CircleButton2.ImageSize = New System.Drawing.Size(50, 50)
        Me.Guna2CircleButton2.Location = New System.Drawing.Point(31, 26)
        Me.Guna2CircleButton2.Margin = New System.Windows.Forms.Padding(4)
        Me.Guna2CircleButton2.Name = "Guna2CircleButton2"
        Me.Guna2CircleButton2.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle
        Me.Guna2CircleButton2.Size = New System.Drawing.Size(89, 70)
        Me.Guna2CircleButton2.TabIndex = 1
        '
        'Guna2DateTimePicker1
        '
        Me.Guna2DateTimePicker1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Guna2DateTimePicker1.BorderRadius = 20
        Me.Guna2DateTimePicker1.Checked = True
        Me.Guna2DateTimePicker1.Font = New System.Drawing.Font("Century Gothic", 10.2!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2DateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.[Long]
        Me.Guna2DateTimePicker1.Location = New System.Drawing.Point(31, 113)
        Me.Guna2DateTimePicker1.Margin = New System.Windows.Forms.Padding(4)
        Me.Guna2DateTimePicker1.MaxDate = New Date(9998, 12, 31, 0, 0, 0, 0)
        Me.Guna2DateTimePicker1.MinDate = New Date(1753, 1, 1, 0, 0, 0, 0)
        Me.Guna2DateTimePicker1.Name = "Guna2DateTimePicker1"
        Me.Guna2DateTimePicker1.Size = New System.Drawing.Size(352, 44)
        Me.Guna2DateTimePicker1.TabIndex = 1
        Me.Guna2DateTimePicker1.Value = New Date(2022, 11, 23, 18, 32, 5, 599)
        '
        'Guna2HtmlLabel1
        '
        Me.Guna2HtmlLabel1.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Guna2HtmlLabel1.Font = New System.Drawing.Font("Century Gothic", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel1.ForeColor = System.Drawing.Color.White
        Me.Guna2HtmlLabel1.Location = New System.Drawing.Point(128, 28)
        Me.Guna2HtmlLabel1.Margin = New System.Windows.Forms.Padding(4)
        Me.Guna2HtmlLabel1.Name = "Guna2HtmlLabel1"
        Me.Guna2HtmlLabel1.Size = New System.Drawing.Size(186, 43)
        Me.Guna2HtmlLabel1.TabIndex = 0
        Me.Guna2HtmlLabel1.Text = "CALENDAR"
        '
        'Guna2GradientPanel1
        '
        Me.Guna2GradientPanel1.BorderRadius = 30
        Me.Guna2GradientPanel1.Controls.Add(Me.Guna2CircleButton2)
        Me.Guna2GradientPanel1.Controls.Add(Me.Guna2DateTimePicker1)
        Me.Guna2GradientPanel1.Controls.Add(Me.Guna2HtmlLabel1)
        Me.Guna2GradientPanel1.FillColor = System.Drawing.Color.FromArgb(CType(CType(244, Byte), Integer), CType(CType(142, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.Guna2GradientPanel1.FillColor2 = System.Drawing.Color.FromArgb(CType(CType(244, Byte), Integer), CType(CType(116, Byte), Integer), CType(CType(154, Byte), Integer))
        Me.Guna2GradientPanel1.ForeColor = System.Drawing.Color.White
        Me.Guna2GradientPanel1.Location = New System.Drawing.Point(287, 146)
        Me.Guna2GradientPanel1.Margin = New System.Windows.Forms.Padding(4)
        Me.Guna2GradientPanel1.Name = "Guna2GradientPanel1"
        Me.Guna2GradientPanel1.ShadowDecoration.Color = System.Drawing.Color.FromArgb(CType(CType(244, Byte), Integer), CType(CType(142, Byte), Integer), CType(CType(85, Byte), Integer))
        Me.Guna2GradientPanel1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle
        Me.Guna2GradientPanel1.Size = New System.Drawing.Size(409, 185)
        Me.Guna2GradientPanel1.TabIndex = 46
        '
        'Guna2HtmlLabel2
        '
        Me.Guna2HtmlLabel2.BackColor = System.Drawing.Color.Transparent
        Me.Guna2HtmlLabel2.Font = New System.Drawing.Font("Century Gothic", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Guna2HtmlLabel2.ForeColor = System.Drawing.Color.White
        Me.Guna2HtmlLabel2.Location = New System.Drawing.Point(136, 44)
        Me.Guna2HtmlLabel2.Margin = New System.Windows.Forms.Padding(4)
        Me.Guna2HtmlLabel2.Name = "Guna2HtmlLabel2"
        Me.Guna2HtmlLabel2.Size = New System.Drawing.Size(208, 43)
        Me.Guna2HtmlLabel2.TabIndex = 0
        Me.Guna2HtmlLabel2.Text = "TOTAL SALES"
        '
        'Guna2GradientPanel2
        '
        Me.Guna2GradientPanel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Guna2GradientPanel2.BorderRadius = 30
        Me.Guna2GradientPanel2.Controls.Add(Me.Guna2CircleButton1)
        Me.Guna2GradientPanel2.Controls.Add(Me.countuser)
        Me.Guna2GradientPanel2.Controls.Add(Me.Guna2HtmlLabel2)
        Me.Guna2GradientPanel2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.Guna2GradientPanel2.FillColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(12, Byte), Integer), CType(CType(253, Byte), Integer))
        Me.Guna2GradientPanel2.FillColor2 = System.Drawing.Color.FromArgb(CType(CType(203, Byte), Integer), CType(CType(55, Byte), Integer), CType(CType(200, Byte), Integer))
        Me.Guna2GradientPanel2.ForeColor = System.Drawing.Color.White
        Me.Guna2GradientPanel2.Location = New System.Drawing.Point(797, 146)
        Me.Guna2GradientPanel2.Margin = New System.Windows.Forms.Padding(4)
        Me.Guna2GradientPanel2.Name = "Guna2GradientPanel2"
        Me.Guna2GradientPanel2.Size = New System.Drawing.Size(420, 185)
        Me.Guna2GradientPanel2.TabIndex = 47
        '
        'Guna2CircleButton1
        '
        Me.Guna2CircleButton1.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.Guna2CircleButton1.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.Guna2CircleButton1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.Guna2CircleButton1.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Guna2CircleButton1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.Guna2CircleButton1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2CircleButton1.ForeColor = System.Drawing.Color.White
        Me.Guna2CircleButton1.ImageSize = New System.Drawing.Size(50, 50)
        Me.Guna2CircleButton1.Location = New System.Drawing.Point(32, 29)
        Me.Guna2CircleButton1.Margin = New System.Windows.Forms.Padding(4)
        Me.Guna2CircleButton1.Name = "Guna2CircleButton1"
        Me.Guna2CircleButton1.ShadowDecoration.Mode = Guna.UI2.WinForms.Enums.ShadowMode.Circle
        Me.Guna2CircleButton1.Size = New System.Drawing.Size(84, 81)
        Me.Guna2CircleButton1.TabIndex = 1
        '
        'countuser
        '
        Me.countuser.BackColor = System.Drawing.Color.Transparent
        Me.countuser.Font = New System.Drawing.Font("Century Gothic", 26.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.countuser.ForeColor = System.Drawing.Color.White
        Me.countuser.Location = New System.Drawing.Point(236, 105)
        Me.countuser.Margin = New System.Windows.Forms.Padding(4)
        Me.countuser.Name = "countuser"
        Me.countuser.Size = New System.Drawing.Size(23, 43)
        Me.countuser.TabIndex = 0
        Me.countuser.Text = "7"
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(CType(1, Byte), Integer), CType(CType(73, Byte), Integer), CType(CType(124, Byte), Integer))
        Me.Panel2.Controls.Add(Me.Label2)
        Me.Panel2.Controls.Add(Me.close_bttn)
        Me.Panel2.Dock = System.Windows.Forms.DockStyle.Top
        Me.Panel2.Location = New System.Drawing.Point(262, 0)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(968, 100)
        Me.Panel2.TabIndex = 52
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Candara", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.White
        Me.Label2.Location = New System.Drawing.Point(41, 29)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(165, 39)
        Me.Label2.TabIndex = 4
        Me.Label2.Text = "Dashboard"
        '
        'close_bttn
        '
        Me.close_bttn.Cursor = System.Windows.Forms.Cursors.Hand
        Me.close_bttn.Image = Global.StMarthaManagementSystem.My.Resources.Resources.close1
        Me.close_bttn.Location = New System.Drawing.Point(931, 3)
        Me.close_bttn.Name = "close_bttn"
        Me.close_bttn.Size = New System.Drawing.Size(34, 30)
        Me.close_bttn.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.close_bttn.TabIndex = 12
        Me.close_bttn.TabStop = False
        '
        'DashboardFrame
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 19.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1230, 700)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Guna2GradientPanel1)
        Me.Controls.Add(Me.Guna2GradientPanel2)
        Me.Controls.Add(Me.MenuPanel)
        Me.Font = New System.Drawing.Font("Candara", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Margin = New System.Windows.Forms.Padding(4)
        Me.Name = "DashboardFrame"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "DashboardFrame"
        Me.Panel1.ResumeLayout(False)
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.MenuPanel.ResumeLayout(False)
        Me.Guna2GradientPanel1.ResumeLayout(False)
        Me.Guna2GradientPanel1.PerformLayout()
        Me.Guna2GradientPanel2.ResumeLayout(False)
        Me.Guna2GradientPanel2.PerformLayout()
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        CType(Me.close_bttn, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents close_bttn As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents PictureBox1 As PictureBox
    Friend WithEvents records As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents regnewclient As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents dashboard As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Logout As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Panel1 As Panel
    Friend WithEvents MenuPanel As Panel
    Friend WithEvents salesreport As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents Guna2CircleButton2 As Guna.UI2.WinForms.Guna2CircleButton
    Friend WithEvents Guna2DateTimePicker1 As Guna.UI2.WinForms.Guna2DateTimePicker
    Friend WithEvents Guna2HtmlLabel1 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2GradientPanel1 As Guna.UI2.WinForms.Guna2GradientPanel
    Friend WithEvents Guna2HtmlLabel2 As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Guna2GradientPanel2 As Guna.UI2.WinForms.Guna2GradientPanel
    Friend WithEvents Guna2CircleButton1 As Guna.UI2.WinForms.Guna2CircleButton
    Friend WithEvents countuser As Guna.UI2.WinForms.Guna2HtmlLabel
    Friend WithEvents Panel2 As Panel
    Friend WithEvents Label2 As Label
End Class
