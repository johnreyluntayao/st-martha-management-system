﻿Public Class DashboardFrame

    Private Sub regnewclient_Click(sender As Object, e As EventArgs) Handles regnewclient.Click
        ManageDocFrame.Show()
        Me.Hide()
    End Sub

    Private Sub records_Click(sender As Object, e As EventArgs) Handles records.Click
        RecordFrame.Show()
        Me.Hide()
    End Sub

    Private Sub salesreport_Click(sender As Object, e As EventArgs) Handles salesreport.Click
        SalesReportFrame.Show()
        Me.Hide()
    End Sub

    Private Sub Guna2Button1_Click(sender As Object, e As EventArgs) Handles Logout.Click
        Login.Show()
        Me.Hide()
    End Sub

    Private Sub close_bttn_Click(sender As Object, e As EventArgs) Handles close_bttn.Click
        Application.Exit()
    End Sub


End Class