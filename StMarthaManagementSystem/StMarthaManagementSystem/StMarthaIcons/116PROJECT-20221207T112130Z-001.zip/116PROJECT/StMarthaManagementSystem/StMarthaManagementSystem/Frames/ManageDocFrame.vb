﻿Public Class ManageDocFrame
    Dim isCollapsed As Boolean = True
    Dim isCollapsed2 As Boolean = True
    Public Sub addform(frm As Form)
        Try
            contentPanel.Controls.Clear()
            frm.TopMost = True
            frm.TopLevel = False
            frm.Dock = DockStyle.Fill
            contentPanel.Controls.Add(frm)
            frm.Show()
        Catch ex As Exception
            MessageBox.Show(ex.ToString)
        End Try
    End Sub
    Private Sub change_form(menu As String)
        Select Case menu
            Case "AddClientForm"
                addform(ClientForm)
            Case "AddContractForm"
                addform(ContractInformation)
            Case "AddContractPaymentForm"
                addform(ContractPaymentForm)
            Case "AddPlanForm"
                addform(PlanForm)
            Case "AddPlanPaymentForm"
                addform(PlanPaymentForm)

        End Select
    End Sub
    Private Sub addclient_btn_Click(sender As Object, e As EventArgs) Handles addclient_btn.Click
        change_form("AddClientForm")
        conn.Close()
    End Sub

    Private Sub addcontract_btn_Click(sender As Object, e As EventArgs) Handles addcontract_btn.Click
        change_form("AddContractForm")
        conn.Close()
    End Sub

    Private Sub addplan_btn_Click(sender As Object, e As EventArgs) Handles addplan_btn.Click
        change_form("AddPlanForm")
        conn.Close()
    End Sub


    Private Sub addcontractp_Click(sender As Object, e As EventArgs) Handles addcontractp.Click
        change_form("AddContractPaymentForm")
        conn.Close()
    End Sub


    Private Sub addplanp_Click(sender As Object, e As EventArgs) Handles addplanp.Click
        change_form("AddPlanPaymentForm")
        conn.Close()
    End Sub

    Private Sub logOut_Click(sender As Object, e As EventArgs) Handles logOut.Click
        Login.Show()
        Me.Hide()
    End Sub

    Private Sub payment_Click(sender As Object, e As EventArgs) Handles payment.Click
        isCollapsed2 = False
        Timer1.Start()
    End Sub

    Private Sub contentPanel_Paint(sender As Object, e As PaintEventArgs) Handles contentPanel.Paint
        PaymentPanel.Size = PaymentPanel.MinimumSize
    End Sub

    Private Sub Timer1_Tick_1(sender As Object, e As EventArgs) Handles Timer1.Tick
        If isCollapsed Then
            PaymentPanel.Height += 10
            If PaymentPanel.Size = PaymentPanel.MaximumSize Then
                Timer1.Stop()
                isCollapsed = False
            End If
        Else
            PaymentPanel.Height -= 10
            If PaymentPanel.Size = PaymentPanel.MinimumSize Then
                Timer1.Stop()
                isCollapsed = True
            End If
        End If
    End Sub

    Private Sub back_bttn_Click(sender As Object, e As EventArgs) Handles back_bttn.Click
        DashboardFrame.Show()
        Me.Hide()
    End Sub
End Class