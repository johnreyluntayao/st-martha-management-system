﻿Public Class SalesReportFrame
    Private Sub salesreport_Click(sender As Object, e As EventArgs) Handles salesreport.Click

    End Sub

    Private Sub dashboard_Click(sender As Object, e As EventArgs) Handles dashboard.Click
        DashboardFrame.Show()
        Me.Hide()
    End Sub

    Private Sub LogOut_Click(sender As Object, e As EventArgs) Handles LogOut.Click
        Login.Show()
        Me.Hide()
    End Sub
End Class