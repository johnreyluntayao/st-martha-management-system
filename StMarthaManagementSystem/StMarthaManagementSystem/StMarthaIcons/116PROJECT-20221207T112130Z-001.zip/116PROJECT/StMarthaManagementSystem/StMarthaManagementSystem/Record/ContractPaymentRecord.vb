﻿Imports MySql.Data.MySqlClient

Public Class ContractPaymentRecord
    Private Sub ContractPaymentRecord_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
        conn.Open()
        disp_data()
    End Sub
    Public Sub disp_data()
        cmd = conn.CreateCommand()
        cmd.CommandType = CommandType.Text
        cmd.CommandText = "SELECT contract_payment.Payment_ID,contract_client.Client_Name,contract_payment.Contract_ID,contract_payment.Deposit,contract_payment.Date,contract_payment.Balance FROM contract_payment INNER JOIN contract_client ON contract_client.Client_ID = contract_payment.Payment_ID"
        cmd.ExecuteNonQuery()
        Dim dt As New DataTable()
        Dim da As New MySqlDataAdapter(cmd)
        da.Fill(dt)
        contractPaymentRecDGV.DataSource = dt
    End Sub

    Private Sub contractPaymentRecDGV_CellClick(sender As Object, e As DataGridViewCellEventArgs) Handles contractPaymentRecDGV.CellClick

    End Sub
End Class