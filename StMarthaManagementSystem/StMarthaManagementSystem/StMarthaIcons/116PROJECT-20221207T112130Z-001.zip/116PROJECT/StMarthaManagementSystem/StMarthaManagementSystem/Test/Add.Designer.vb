﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Add
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Guna2Button1 = New Guna.UI2.WinForms.Guna2Button()
        Me.totalamount_TB = New Guna.UI2.WinForms.Guna2TextBox()
        Me.flower_TB = New Guna.UI2.WinForms.Guna2TextBox()
        Me.tarpulin_TB = New Guna.UI2.WinForms.Guna2TextBox()
        Me.SuspendLayout()
        '
        'Guna2Button1
        '
        Me.Guna2Button1.DisabledState.BorderColor = System.Drawing.Color.DarkGray
        Me.Guna2Button1.DisabledState.CustomBorderColor = System.Drawing.Color.DarkGray
        Me.Guna2Button1.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer), CType(CType(169, Byte), Integer))
        Me.Guna2Button1.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer), CType(CType(141, Byte), Integer))
        Me.Guna2Button1.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.Guna2Button1.ForeColor = System.Drawing.Color.White
        Me.Guna2Button1.Location = New System.Drawing.Point(349, 346)
        Me.Guna2Button1.Name = "Guna2Button1"
        Me.Guna2Button1.Size = New System.Drawing.Size(180, 45)
        Me.Guna2Button1.TabIndex = 3
        Me.Guna2Button1.Text = "Save"
        '
        'totalamount_TB
        '
        Me.totalamount_TB.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.totalamount_TB.DefaultText = ""
        Me.totalamount_TB.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.totalamount_TB.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.totalamount_TB.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.totalamount_TB.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.totalamount_TB.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.totalamount_TB.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.totalamount_TB.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.totalamount_TB.Location = New System.Drawing.Point(308, 218)
        Me.totalamount_TB.Name = "totalamount_TB"
        Me.totalamount_TB.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.totalamount_TB.PlaceholderText = ""
        Me.totalamount_TB.SelectedText = ""
        Me.totalamount_TB.Size = New System.Drawing.Size(160, 36)
        Me.totalamount_TB.TabIndex = 98
        '
        'flower_TB
        '
        Me.flower_TB.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.flower_TB.DefaultText = ""
        Me.flower_TB.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.flower_TB.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.flower_TB.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.flower_TB.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.flower_TB.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.flower_TB.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.flower_TB.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.flower_TB.Location = New System.Drawing.Point(308, 157)
        Me.flower_TB.Name = "flower_TB"
        Me.flower_TB.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.flower_TB.PlaceholderText = ""
        Me.flower_TB.SelectedText = ""
        Me.flower_TB.Size = New System.Drawing.Size(160, 36)
        Me.flower_TB.TabIndex = 97
        '
        'tarpulin_TB
        '
        Me.tarpulin_TB.Cursor = System.Windows.Forms.Cursors.IBeam
        Me.tarpulin_TB.DefaultText = ""
        Me.tarpulin_TB.DisabledState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer), CType(CType(208, Byte), Integer))
        Me.tarpulin_TB.DisabledState.FillColor = System.Drawing.Color.FromArgb(CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer), CType(CType(226, Byte), Integer))
        Me.tarpulin_TB.DisabledState.ForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.tarpulin_TB.DisabledState.PlaceholderForeColor = System.Drawing.Color.FromArgb(CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer), CType(CType(138, Byte), Integer))
        Me.tarpulin_TB.FocusedState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.tarpulin_TB.Font = New System.Drawing.Font("Segoe UI", 9.0!)
        Me.tarpulin_TB.HoverState.BorderColor = System.Drawing.Color.FromArgb(CType(CType(94, Byte), Integer), CType(CType(148, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.tarpulin_TB.Location = New System.Drawing.Point(308, 95)
        Me.tarpulin_TB.Name = "tarpulin_TB"
        Me.tarpulin_TB.PasswordChar = Global.Microsoft.VisualBasic.ChrW(0)
        Me.tarpulin_TB.PlaceholderText = ""
        Me.tarpulin_TB.SelectedText = ""
        Me.tarpulin_TB.Size = New System.Drawing.Size(160, 36)
        Me.tarpulin_TB.TabIndex = 96
        '
        'Add
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(800, 450)
        Me.Controls.Add(Me.totalamount_TB)
        Me.Controls.Add(Me.flower_TB)
        Me.Controls.Add(Me.tarpulin_TB)
        Me.Controls.Add(Me.Guna2Button1)
        Me.Name = "Add"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Add"
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Guna2Button1 As Guna.UI2.WinForms.Guna2Button
    Friend WithEvents totalamount_TB As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents flower_TB As Guna.UI2.WinForms.Guna2TextBox
    Friend WithEvents tarpulin_TB As Guna.UI2.WinForms.Guna2TextBox
End Class
