﻿Public Class Add





    Private Sub tarpulin_TB_TextChanged_1(sender As Object, e As EventArgs) Handles tarpulin_TB.TextChanged
        If tarpulin_TB.Text = "" Or flower_TB.Text = "" Then
        Else
            Dim tarpulinVal As Double = tarpulin_TB.Text
            Dim flowerVal As Double = flower_TB.Text
            Dim total As Double = tarpulinVal + flowerVal
            totalamount_TB.Text = (FormatNumber(total))
        End If
    End Sub

    Private Sub flower_TB_TextChanged_1(sender As Object, e As EventArgs) Handles flower_TB.TextChanged
        If tarpulin_TB.Text = "" Or flower_TB.Text = "" Then
        Else
            Dim flowerVal As Double = flower_TB.Text
            Dim tarpulinVal As Double = tarpulin_TB.Text
            Dim total As Double = tarpulinVal + flowerVal
            totalamount_TB.Text = (FormatNumber(total))
        End If
    End Sub
    Private Sub Guna2Button1_Click(sender As Object, e As EventArgs) Handles Guna2Button1.Click
        If conn.State = ConnectionState.Open Then
            conn.Close()
        End If
        conn.Open()
        cmd = conn.CreateCommand()
        cmd.CommandText = "INSERT INTO add_ons_price(`Tarpaulin`,`Flower_Arrangement`,`Total_Amount`) VALUES ('" & tarpulin_TB.Text & "', '" & flower_TB.Text & "', '" & totalamount_TB.Text & "')"
        cmd.ExecuteNonQuery()
    End Sub
End Class